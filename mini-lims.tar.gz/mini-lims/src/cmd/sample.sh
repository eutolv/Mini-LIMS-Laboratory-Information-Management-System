#!/usr/bin/env bash
# sample.sh - sample registration, listing, editing and the status workflow.
# The transition rules live in the DATABASE (workflow_transitions + triggers). This file adds
# friendlier errors and the role check, but the database refuses illegal changes on its own.

readonly SAMPLE_STATUSES="RECEIVED REGISTERED IN_TESTING COMPLETED REVIEWED APPROVED CANCELLED"

# sample_status_of ID -> prints the current status; exits 4 if the sample does not exist.
sample_status_of() {
    valid_sample_id "$1"
    local st; st=$(db_query "SELECT status FROM samples WHERE code = $(sql_quote "$1");")
    [[ -n $st ]] || fail "$EX_NOTFOUND" "Sample '$1' does not exist."
    printf '%s' "$st"
}

# Inside our write transaction (BEGIN IMMEDIATE) the newest row is ours.
readonly LAST_SAMPLE_CODE="(SELECT code FROM samples WHERE id = (SELECT MAX(id) FROM samples))"

readonly SAMPLE_SELECT="SELECT s.code, c.code AS client, c.name AS client_name, s.sample_type AS type,
       s.status, s.priority, s.collection_date AS collected, s.reception_date AS received,
       s.description, s.metadata, s.created_by, s.created_at, s.updated_at
  FROM samples s JOIN clients c ON c.id = s.client_id"

sample_json_expr() { # json snapshot of one sample, used for audit old/new values
    printf "json_object('status',status,'priority',priority,'collected',collection_date,'received',reception_date,'description',description,'metadata',metadata)"
}

cmd_sample() {
    db_require; auth_init
    local sub=${1:-}; shift || true
    case $sub in
        create)    sample_create "$@" ;;
        list)      sample_list "$@" ;;
        show)      sample_show "$@" ;;
        update)    sample_update "$@" ;;
        delete)    sample_delete "$@" ;;
        status)    sample_status "$@" ;;
        set-status) sample_set_status "$@" ;;
        register)  sample_shortcut REGISTERED "$@" ;;
        complete)  sample_shortcut COMPLETED "$@" ;;
        review)    sample_shortcut REVIEWED "$@" ;;
        approve)   sample_shortcut APPROVED "$@" ;;
        cancel)    sample_shortcut CANCELLED "$@" ;;
        reopen)    sample_shortcut IN_TESTING "$@" ;;
        *) fail "$EX_USAGE" "Unknown or missing sample action '$sub'." "Try: lab sample list" ;;
    esac
}

sample_create() {
    require_perm sample.create
    parse_args "client type collected received priority description metadata" "$@"
    ((${#POS[@]} == 0)) || fail "$EX_USAGE" "Unexpected argument '${POS[0]}'." "Samples are created with options only."
    local k; for k in client type collected; do
        [[ -n ${OPT[$k]:-} ]] || fail "$EX_USAGE" "Missing required option --$k." "Usage: lab sample create --client CODE --type TYPE --collected YYYY-MM-DD"
    done
    local client=${OPT[client]} type=${OPT[type]} collected=${OPT[collected]}
    local received=${OPT[received]:-$(today)} priority=${OPT[priority]:-ROUTINE}
    local description=${OPT[description]:-} metadata=${OPT[metadata]:-}
    valid_client_code "$client"; valid_date collected "$collected"; valid_date received "$received"
    [[ $received < $collected ]] && fail "$EX_VALIDATION" "Reception date is before collection date." "collected=$collected received=$received"
    valid_enum priority "$priority" ROUTINE URGENT
    valid_text description "$description" 500
    [[ -z $metadata ]] || { valid_text metadata "$metadata" 2000; valid_json "$metadata"; }
    [[ $type =~ ^[A-Z_]{2,20}$ ]] || fail "$EX_VALIDATION" "Invalid sample type '$type'."
    db_exists "SELECT 1 FROM clients WHERE code = $(sql_quote "$client");" || fail "$EX_NOTFOUND" "Client '$client' does not exist."
    db_exists "SELECT 1 FROM sample_types WHERE code = $(sql_quote "$type");" || fail "$EX_NOTFOUND" "Sample type '$type' does not exist." "Known types: $(db_query "SELECT group_concat(code, ', ') FROM sample_types;")"

    local newcode
    newcode=$(db_tx "UPDATE counters SET value = value + 1 WHERE name = 'sample';
        INSERT INTO samples(code, client_id, sample_type, collection_date, reception_date, priority, description, metadata, created_by)
        VALUES ((SELECT printf('SAM-%04d', value) FROM counters WHERE name = 'sample'),
                (SELECT id FROM clients WHERE code = $(sql_quote "$client")),
                $(sql_quote "$type"), $(sql_quote "$collected"), $(sql_quote "$received"), $(sql_quote "$priority"),
                $(sql_quote_or_null "$description"), $(sql_quote_or_null "$metadata"), $(sql_quote "$LAB_USER_NAME"));
        SELECT code FROM samples WHERE id = last_insert_rowid();
        $(audit_sql SAMPLE_CREATED SAMPLE "@$LAST_SAMPLE_CODE" "@$LAST_SAMPLE_CODE" NULL \
            "(SELECT $(sample_json_expr) FROM samples WHERE id = (SELECT MAX(id) FROM samples))" "")")
    log INFO "sample created id=$newcode"
    info "Sample $newcode created (status RECEIVED)."
    info "Next: lab sample register $newcode"
}

sample_list() {
    parse_args "status client" "$@"; need_pos 0 "sample list [--status S] [--client CODE]"
    local where="1=1"
    if [[ -n ${OPT[status]:-} ]]; then valid_enum status "${OPT[status]}" $SAMPLE_STATUSES; where+=" AND s.status = $(sql_quote "${OPT[status]}")"; fi
    if [[ -n ${OPT[client]:-} ]]; then valid_client_code "${OPT[client]}"; where+=" AND c.code = $(sql_quote "${OPT[client]}")"; fi
    db_show "SELECT s.code, c.code AS client, s.sample_type AS type, s.status, s.priority,
                    s.collection_date AS collected, s.reception_date AS received
             FROM samples s JOIN clients c ON c.id = s.client_id WHERE $where ORDER BY s.id;"
}

sample_show() {
    parse_args "" "$@"; need_pos 1 "sample show SAMPLE_ID"
    sample_status_of "${POS[0]}" >/dev/null
    local q; q=$(sql_quote "${POS[0]}")
    if [[ $LAB_FORMAT == json ]]; then
        db_exec "$SAMPLE_SELECT WHERE s.code = $q;" -json
    else
        db_exec "$SAMPLE_SELECT WHERE s.code = $q;" -line
        echo; echo "Requested tests:"
        db_show "SELECT test, value, unit, flag, result_status AS status FROM v_sample_results WHERE sample = $q ORDER BY test;"
    fi
}

sample_update() {
    require_perm sample.update
    parse_args "priority description metadata collected received" "$@"; need_pos 1 "sample update SAMPLE_ID [--priority P --description T --metadata JSON --collected D --received D]"
    local id=${POS[0]}; sample_status_of "$id" >/dev/null
    ((${#OPT[@]} > 0)) || fail "$EX_USAGE" "Nothing to update." "Give at least one option, e.g. --priority URGENT"
    local sets=("updated_at = strftime('%Y-%m-%dT%H:%M:%SZ','now')") k v
    for k in "${!OPT[@]}"; do
        v=${OPT[$k]}
        case $k in
            priority)    valid_enum priority "$v" ROUTINE URGENT; sets+=("priority = $(sql_quote "$v")") ;;
            description) valid_text description "$v" 500; sets+=("description = $(sql_quote_or_null "$v")") ;;
            metadata)    if [[ -n $v ]]; then valid_text metadata "$v" 2000; valid_json "$v"; fi
                         sets+=("metadata = $(sql_quote_or_null "$v")") ;;
            collected)   valid_date collected "$v"; sets+=("collection_date = $(sql_quote "$v")") ;;
            received)    valid_date received "$v"; sets+=("reception_date = $(sql_quote "$v")") ;;
        esac
    done
    local q IFS=,; q=$(sql_quote "$id")
    db_tx "$(snap_begin "$(sample_json_expr) AS j FROM samples WHERE code = $q")
           UPDATE samples SET ${sets[*]} WHERE code = $q;
           $(audit_sql SAMPLE_UPDATED SAMPLE "$id" "$id" "$SNAP_OLD" "(SELECT $(sample_json_expr) FROM samples WHERE code = $q)" "")
           $(snap_end)"
    info "Sample $id updated."
}

sample_delete() {
    require_perm sample.delete
    parse_args "" "$@"; need_pos 1 "sample delete SAMPLE_ID"
    local id=${POS[0]} q; sample_status_of "$id" >/dev/null; q=$(sql_quote "$id")
    db_tx "$(snap_begin "$(sample_json_expr) AS j FROM samples WHERE code = $q")
           DELETE FROM samples WHERE code = $q;
           $(audit_sql SAMPLE_DELETED SAMPLE "$id" "$id" "$SNAP_OLD" NULL "")
           $(snap_end)"
    info "Sample $id deleted (the audit trail is kept)."
}

sample_status() {
    parse_args "" "$@"; need_pos 1 "sample status SAMPLE_ID"
    sample_status_of "${POS[0]}" >/dev/null
    local q; q=$(sql_quote "${POS[0]}")
    db_show "SELECT s.code, s.status,
                    COALESCE((SELECT group_concat(to_status, ', ') FROM workflow_transitions w WHERE w.from_status = s.status), '(final)') AS next_allowed,
                    (SELECT count(*) FROM test_requests tr WHERE tr.sample_id = s.id) AS tests_requested,
                    (SELECT count(*) FROM test_requests tr JOIN results r ON r.request_id = tr.id WHERE tr.sample_id = s.id) AS results_entered,
                    (SELECT count(*) FROM test_requests tr JOIN results r ON r.request_id = tr.id WHERE tr.sample_id = s.id AND r.flag <> 'NORMAL') AS flagged_results
             FROM samples s WHERE s.code = $q;"
}

sample_shortcut() { local target=$1; shift; sample_transition "$target" "$@"; }
sample_set_status() { parse_args "reason" "$@"; ((${#POS[@]} == 2)) || fail "$EX_USAGE" "Wrong number of arguments." "Usage: lab sample set-status SAMPLE_ID NEW_STATUS"
                      valid_enum status "${POS[1]}" $SAMPLE_STATUSES; sample_transition "${POS[1]}" "${POS[0]}" ${OPT[reason]:+--reason "${OPT[reason]}"}; }

# sample_transition TARGET SAMPLE_ID [--reason TEXT]
sample_transition() {
    local target=$1; shift
    parse_args "reason" "$@"; need_pos 1 "sample <register|complete|review|approve|cancel|reopen> SAMPLE_ID [--reason TEXT]"
    local id=${POS[0]} reason=${OPT[reason]:-} current roles q
    valid_text reason "$reason" 300
    current=$(sample_status_of "$id"); q=$(sql_quote "$id")
    [[ $current != "$target" ]] || fail "$EX_CONFLICT" "Sample $id is already $target."
    roles=$(db_query "SELECT allowed_roles FROM workflow_transitions WHERE from_status = '$current' AND to_status = '$target';")
    [[ -n $roles ]] || fail "$EX_CONFLICT" "Cannot change status of $id." "Transition $current -> $target is not allowed. Allowed from $current: $(db_query "SELECT COALESCE(group_concat(to_status, ', '), 'none (final status)') FROM workflow_transitions WHERE from_status = '$current';")"
    [[ ",$roles," == *",$LAB_USER_ROLE,"* ]] || fail "$EX_PERMISSION" "Permission denied." "$current -> $target requires one of: $roles (you are $LAB_USER_ROLE)."

    local extra=""
    if [[ $target == APPROVED ]]; then
        extra=$(audit_sql SAMPLE_APPROVED SAMPLE "$id" "$id" NULL "json_object('status','APPROVED')" "$reason")
    fi
    db_tx "$(snap_begin "json_object('status',status) AS j FROM samples WHERE code = $q")
           UPDATE samples SET status = '$target', updated_at = strftime('%Y-%m-%dT%H:%M:%SZ','now') WHERE code = $q;
           $(audit_sql STATUS_CHANGED SAMPLE "$id" "$id" "$SNAP_OLD" "json_object('status','$target')" "$reason")
           $extra
           $(snap_end)"
    log INFO "status changed sample=$id $current->$target"
    info "Sample $id: $current -> $target"
}
