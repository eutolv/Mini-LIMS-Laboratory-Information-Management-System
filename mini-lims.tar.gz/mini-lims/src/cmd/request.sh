#!/usr/bin/env bash
# request.sh - link a sample to the tests that must be performed on it.

cmd_request() {
    db_require; auth_init
    local sub=${1:-}; shift || true
    case $sub in
        create) request_create "$@" ;;
        list)   parse_args "" "$@"; need_pos 1 "request list SAMPLE_ID"
                sample_status_of "${POS[0]}" >/dev/null
                db_show "SELECT test, test_name AS name, result_status AS status FROM v_sample_results WHERE sample = $(sql_quote "${POS[0]}") ORDER BY test;" ;;
        *) fail "$EX_USAGE" "Unknown or missing request action '$sub'." "Try: lab request create SAM-0001 PH" ;;
    esac
}

request_create() {
    require_perm request.create
    parse_args "" "$@"; need_pos 2 "request create SAMPLE_ID TEST_CODE"
    local sample=${POS[0]} test=${POS[1]} st
    st=$(sample_status_of "$sample")          # exit 4 if the sample does not exist
    test_must_exist "$test"                   # exit 4 if the test does not exist
    local qs qt; qs=$(sql_quote "$sample"); qt=$(sql_quote "$test")
    # Friendly pre-checks; the same rules are enforced again by database triggers.
    db_exists "SELECT 1 FROM tests WHERE code = $qt AND active = 1;" || fail "$EX_CONFLICT" "Cannot request test." "Test $test is inactive."
    if db_exists "SELECT 1 FROM test_requests tr JOIN samples s ON s.id = tr.sample_id JOIN tests t ON t.id = tr.test_id WHERE s.code = $qs AND t.code = $qt;"; then
        fail "$EX_CONFLICT" "Cannot request test." "Test $test is already requested for sample $sample."
    fi
    case $st in
        REGISTERED|IN_TESTING) ;;
        *) fail "$EX_CONFLICT" "Cannot request test." "Sample $sample is $st; tests can only be requested while REGISTERED or IN_TESTING." ;;
    esac
    db_tx "INSERT INTO test_requests(sample_id, test_id, requested_by)
             SELECT s.id, t.id, $(sql_quote "$LAB_USER_NAME") FROM samples s, tests t WHERE s.code = $qs AND t.code = $qt;
           $(audit_sql TEST_REQUESTED REQUEST "$sample/$test" "$sample" NULL "json_object('test',$qt)" "")"
    log INFO "test requested sample=$sample test=$test"
    info "Requested $test for $sample."
}
