#!/usr/bin/env bash
# test.sh - the test catalogue, including each test's specification (limits used for flagging).

# test_exists CODE -> exits 4 if unknown.
test_must_exist() {
    valid_test_code "$1"
    db_exists "SELECT 1 FROM tests WHERE code = $(sql_quote "$1");" || fail "$EX_NOTFOUND" "Test '$1' does not exist." "See: lab test list"
}

cmd_test() {
    db_require; auth_init
    local sub=${1:-}; shift || true
    case $sub in
        list)   db_show "SELECT code, name, unit, datatype, min_value AS min, max_value AS max, method,
                                CASE active WHEN 1 THEN 'yes' ELSE 'no' END AS active FROM tests ORDER BY code;" ;;
        show)   parse_args "" "$@"; need_pos 1 "test show CODE"; test_must_exist "${POS[0]}"
                if [[ $LAB_FORMAT == json ]]; then db_exec "SELECT * FROM tests WHERE code = $(sql_quote "${POS[0]}");" -json
                else db_exec "SELECT * FROM tests WHERE code = $(sql_quote "${POS[0]}");" -line; fi ;;
        create) test_create "$@" ;;
        update) test_update "$@" ;;
        *) fail "$EX_USAGE" "Unknown or missing test action '$sub'." "Try: lab test list" ;;
    esac
}

# Turn --min/--max/... options into SQL fragments. Sets globals T_COLS / T_VALS.
test_collect() {
    T_COLS=(); T_VALS=()
    local k v col
    for k in "${!OPT[@]}"; do
        v=${OPT[$k]}
        case $k in
            name)        valid_text name "$v" 100; [[ -n $v ]] || fail "$EX_VALIDATION" "Test name must not be blank."; col=name ;;
            description) valid_text description "$v" 300; col=description ;;
            unit)        valid_text unit "$v" 20; col=unit ;;
            method)      valid_text method "$v" 100; col=method ;;
            allowed)     [[ $v =~ ^[A-Za-z0-9_\ -]+(,[A-Za-z0-9_\ -]+)*$ ]] || fail "$EX_VALIDATION" "Invalid --allowed list '$v'." "Use comma-separated values, e.g. NONE,MILD,STRONG"; col=allowed_values ;;
            min|max|pmin|pmax)
                valid_number "--$k" "$v"
                case $k in min) col=min_value ;; max) col=max_value ;; pmin) col=physical_min ;; pmax) col=physical_max ;; esac
                T_COLS+=("$col"); T_VALS+=("$v"); continue ;;   # numbers are validated, so safe unquoted
            datatype)    valid_enum datatype "$v" NUMERIC TEXT ENUM; col=datatype ;;
            active)      valid_enum active "$v" 0 1; T_COLS+=(active); T_VALS+=("$v"); continue ;;
            *) continue ;;
        esac
        T_COLS+=("$col"); T_VALS+=("$(sql_quote_or_null "$v")")
    done
}

test_create() {
    require_perm test.create
    parse_args "datatype unit min max pmin pmax allowed method description" "$@"
    need_pos 2 "test create CODE NAME --datatype NUMERIC|TEXT|ENUM [--unit U --min N --max N --pmin N --pmax N --allowed A,B --method M]"
    local code=${POS[0]} name=${POS[1]}
    valid_test_code "$code"
    [[ -n ${OPT[datatype]:-} ]] || fail "$EX_USAGE" "Missing required option --datatype."
    OPT[name]=$name
    if [[ ${OPT[datatype]} != NUMERIC ]] && [[ -n ${OPT[min]:-}${OPT[max]:-}${OPT[pmin]:-}${OPT[pmax]:-} ]]; then
        fail "$EX_VALIDATION" "Numeric limits only apply to NUMERIC tests."
    fi
    if [[ ${OPT[datatype]} == ENUM && -z ${OPT[allowed]:-} ]]; then fail "$EX_VALIDATION" "ENUM tests require --allowed."; fi
    test_collect
    local IFS=,
    db_tx "INSERT INTO tests(code, ${T_COLS[*]}) VALUES ($(sql_quote "$code"), ${T_VALS[*]});
           $(audit_sql TEST_CREATED TEST "$code" "" NULL "json_object('name',$(sql_quote "$name"),'datatype',$(sql_quote "${OPT[datatype]}"))" "")"
    info "Test $code created."
}

test_update() {
    require_perm test.update
    parse_args "name description unit method allowed min max pmin pmax datatype active" "$@"
    need_pos 1 "test update CODE [--name N --unit U --min N --max N --active 0|1 ...]"
    local code=${POS[0]}; test_must_exist "$code"
    ((${#OPT[@]} > 0)) || fail "$EX_USAGE" "Nothing to update."
    test_collect
    local sets=() i; for i in "${!T_COLS[@]}"; do sets+=("${T_COLS[$i]} = ${T_VALS[$i]}"); done
    local q IFS=,; q=$(sql_quote "$code")
    local snap="json_object('name',name,'unit',unit,'min',min_value,'max',max_value,'pmin',physical_min,'pmax',physical_max,'active',active)"
    db_tx "$(snap_begin "$snap AS j FROM tests WHERE code = $q")
           UPDATE tests SET ${sets[*]} WHERE code = $q;
           $(audit_sql TEST_UPDATED TEST "$code" "" "$SNAP_OLD" "(SELECT $snap FROM tests WHERE code = $q)" "")
           $(snap_end)"
    info "Test $code updated. (Existing results keep the flags they were given.)"
}
