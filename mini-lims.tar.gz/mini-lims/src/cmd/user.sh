#!/usr/bin/env bash
# user.sh - user accounts and roles (no passwords: see auth.sh limitations).

cmd_user() {
    db_require; auth_init
    local sub=${1:-}; shift || true
    case $sub in
        list)   db_show "SELECT username, full_name AS name, role, CASE active WHEN 1 THEN 'yes' ELSE 'no' END AS active, created_at FROM users ORDER BY username;" ;;
        create) user_create "$@" ;;
        update) user_update "$@" ;;
        *) fail "$EX_USAGE" "Unknown or missing user action '$sub'." "Try: lab user list" ;;
    esac
}

user_create() {
    require_perm user.create
    parse_args "name" "$@"; need_pos 2 "user create USERNAME ROLE [--name FULL_NAME]"
    local u=${POS[0]} role=${POS[1]} name=${OPT[name]:-}
    valid_username "$u"; valid_enum role "$role" ADMIN ANALYST REVIEWER; valid_text name "$name" 100
    db_tx "INSERT INTO users(username, full_name, role) VALUES ($(sql_quote "$u"), $(sql_quote_or_null "$name"), $(sql_quote "$role"));
           $(audit_sql USER_CREATED USER "$u" "" NULL "json_object('role',$(sql_quote "$role"))" "")"
    info "User $u created with role $role."
}

user_update() {
    require_perm user.update
    parse_args "role active name" "$@"; need_pos 1 "user update USERNAME [--role R --active 0|1 --name N]"
    local u=${POS[0]} sets=() k; valid_username "$u"
    db_exists "SELECT 1 FROM users WHERE username = $(sql_quote "$u");" || fail "$EX_NOTFOUND" "User '$u' does not exist."
    ((${#OPT[@]} > 0)) || fail "$EX_USAGE" "Nothing to update."
    for k in "${!OPT[@]}"; do
        case $k in
            role)   valid_enum role "${OPT[$k]}" ADMIN ANALYST REVIEWER; sets+=("role = $(sql_quote "${OPT[$k]}")") ;;
            active) valid_enum active "${OPT[$k]}" 0 1; sets+=("active = ${OPT[$k]}") ;;
            name)   valid_text name "${OPT[$k]}" 100; sets+=("full_name = $(sql_quote_or_null "${OPT[$k]}")") ;;
        esac
    done
    local q IFS=,; q=$(sql_quote "$u")
    db_tx "$(snap_begin "json_object('role',role,'active',active,'name',full_name) AS j FROM users WHERE username = $q")
           UPDATE users SET ${sets[*]} WHERE username = $q;
           $(audit_sql USER_UPDATED USER "$u" "" "$SNAP_OLD" "(SELECT json_object('role',role,'active',active,'name',full_name) FROM users WHERE username = $q)" "")
           $(snap_end)"
    info "User $u updated."
}
