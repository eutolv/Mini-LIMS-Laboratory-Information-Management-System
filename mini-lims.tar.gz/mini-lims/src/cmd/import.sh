#!/usr/bin/env bash
# import.sh - bulk result import from CSV.
# Pipeline: file checks -> header check -> per-row validation -> ONE transaction for all valid rows
# -> report. Bad rows are rejected and reported; valid rows are imported atomically together,
# so a crash mid-import can never leave half a batch in the database.
#
# CSV format (header required):   sample_id,test_code,value,unit
# Limitation: plain CSV only. Quoted fields / embedded commas are rejected, not guessed.

readonly IMPORT_HEADER="sample_id,test_code,value,unit"
readonly IMPORT_MAX_BYTES=5242880

cmd_import() {
    db_require; auth_init; require_perm import.run
    parse_args "dry-run?" "$@"; need_pos 1 "import FILE.csv [--dry-run]"
    local input=${POS[0]} file
    # ---- 1. file checks
    [[ $input != *.csv ]] && fail "$EX_VALIDATION" "Import file must end in .csv." "$input"
    file=$(readlink -f -- "$input" 2>/dev/null) || file=""
    [[ -f $file && -r $file ]] || fail "$EX_NOTFOUND" "Import file not found or not readable." "$input"
    (($(stat -c %s "$file") <= IMPORT_MAX_BYTES)) || fail "$EX_VALIDATION" "Import file is too large." "Limit is $((IMPORT_MAX_BYTES / 1048576)) MB."
    [[ -s $file ]] || fail "$EX_VALIDATION" "Import file is empty."
    # NUL bytes cannot live in a Bash variable, so detect them by comparing sizes with and without NULs.
    (($(tr -d '\000' <"$file" | wc -c) == $(stat -c %s "$file"))) || fail "$EX_VALIDATION" "Import file looks binary." "It contains NUL bytes."

    # ---- 2. header
    local header; IFS= read -r header <"$file" || true
    header=${header#$'\xef\xbb\xbf'}; header=${header%$'\r'}          # tolerate a BOM and Windows line endings
    [[ $header == "$IMPORT_HEADER" ]] || fail "$EX_VALIDATION" "Invalid CSV header." "Expected: $IMPORT_HEADER   Found: ${header:0:80}"

    # ---- 3. parse + validate every row (nothing is written yet)
    local line n=1 total=0 ok=0 bad=0 sql="" report=() seen=" " s t v u extra
    RESULT_AUDIT_NOTE="import"
    while IFS= read -r line || [[ -n $line ]]; do
        n=$((n + 1)); line=${line%$'\r'}
        [[ -n ${line//[[:space:]]/} ]] && total=$((total + 1)) || continue
        if [[ $line == *'"'* ]]; then report+=("Row $n REJECTED: quoted fields are not supported"); bad=$((bad + 1)); continue; fi
        IFS=, read -r s t v u extra <<<"$line"
        if [[ -n ${extra:-} || $(tr -cd ',' <<<"$line" | wc -c) -ne 3 ]]; then report+=("Row $n REJECTED: expected exactly 4 columns"); bad=$((bad + 1)); continue; fi
        s=${s//[[:space:]]/}; t=${t//[[:space:]]/}; v=${v#"${v%%[![:space:]]*}"}; v=${v%"${v##*[![:space:]]}"}; u=${u#"${u%%[![:space:]]*}"}; u=${u%"${u##*[![:space:]]}"}
        if [[ $seen == *" $s/$t "* ]]; then report+=("Row $n REJECTED: duplicate $s/$t within the file"); bad=$((bad + 1)); continue; fi
        seen+="$s/$t "
        if ! result_validate "$s" "$t" "$v" "$u"; then
            report+=("Row $n REJECTED: $R_ERR_HEAD ${R_ERR_REASON}"); bad=$((bad + 1)); continue
        fi
        if ((R_HAS_RESULT == 1)); then report+=("Row $n REJECTED: $s/$t already has a result (use 'lab result update')"); bad=$((bad + 1)); continue; fi
        case $R_SAMPLE_STATUS in
            REGISTERED|IN_TESTING) ;;
            *) report+=("Row $n REJECTED: sample $s is $R_SAMPLE_STATUS; results can only be added while REGISTERED or IN_TESTING"); bad=$((bad + 1)); continue ;;
        esac
        sql+="$(result_insert_sql "$s" "$t" "$v")"$'\n'
        ok=$((ok + 1)); report+=("Row $n ok: $s $t = $v")
    done < <(tail -n +2 "$file")

    # ---- 4. import valid rows in ONE transaction
    local mode="IMPORTED"
    if [[ -n ${OPT[dry-run]:-} ]]; then mode="DRY RUN (nothing written)"
    elif ((ok > 0 || total > 0)); then
        db_tx "$sql
               INSERT INTO import_runs(filename, username, total_rows, imported, rejected) VALUES ($(sql_quote "$(basename "$file")"), $(sql_quote "$LAB_USER_NAME"), $total, $ok, $bad);
               $(audit_sql IMPORT_EXECUTED IMPORT "@(SELECT MAX(id) FROM import_runs)" "" NULL "json_object('file',$(sql_quote "$(basename "$file")"),'rows',$total,'imported',$ok,'rejected',$bad)" "")"
    fi

    # ---- 5. report
    local out="Import report: $(basename "$file")  [$mode]
Rows: $total   imported: $ok   rejected: $bad"
    local r; for r in "${report[@]+"${report[@]}"}"; do out+=$'\n'"  $r"; done
    printf '%s\n' "$out"
    log INFO "import file=$(basename "$file") total=$total ok=$ok rejected=$bad mode=${OPT[dry-run]:+dry-run}"
    if ((total == 0)); then fail "$EX_VALIDATION" "Import file has a header but no data rows."; fi
    ((bad == 0)) || exit "$EX_VALIDATION"      # exit 3: finished, but some rows were rejected
    return 0
}
