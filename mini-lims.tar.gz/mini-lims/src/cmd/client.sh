#!/usr/bin/env bash
# client.sh - laboratory clients (customers).

client_id() { # client_id CODE -> numeric id, or exit 4
    valid_client_code "$1"
    local id; id=$(db_query "SELECT id FROM clients WHERE code = $(sql_quote "$1");")
    [[ -n $id ]] || fail "$EX_NOTFOUND" "Client '$1' does not exist."
    printf '%s' "$id"
}

cmd_client() {
    db_require; auth_init
    local sub=${1:-}; shift || true
    case $sub in
        list)   client_list "$@" ;;
        show)   client_show "$@" ;;
        create) client_create "$@" ;;
        update) client_update "$@" ;;
        *) fail "$EX_USAGE" "Unknown or missing client action '$sub'." "Try: lab client list" ;;
    esac
}

client_list() {
    db_show "SELECT code, name, contact_email AS email, contact_phone AS phone,
                    CASE active WHEN 1 THEN 'yes' ELSE 'no' END AS active
             FROM clients ORDER BY code;"
}

client_show() {
    parse_args "" "$@"; need_pos 1 "client show CODE"; client_id "${POS[0]}" >/dev/null
    db_show "SELECT * FROM clients WHERE code = $(sql_quote "${POS[0]}");"
}

client_create() {
    require_perm client.create
    parse_args "email phone contact" "$@"; need_pos 2 "client create CODE NAME [--email E --phone P --contact C]"
    local code=${POS[0]} name=${POS[1]}
    valid_client_code "$code"; valid_text name "$name" 120
    [[ -n ${name//[[:space:]]/} ]] || fail "$EX_VALIDATION" "Client name must not be blank."
    local email=${OPT[email]:-} phone=${OPT[phone]:-} contact=${OPT[contact]:-}
    valid_text email "$email" 120; valid_text phone "$phone" 40; valid_text contact "$contact" 120
    if [[ -n $email && ! $email =~ ^[^@[:space:]]+@[^@[:space:]]+\.[^@[:space:]]+$ ]]; then
        fail "$EX_VALIDATION" "Invalid email '$email'."
    fi
    db_tx "INSERT INTO clients(code, name, contact_name, contact_email, contact_phone)
           VALUES ($(sql_quote "$code"), $(sql_quote "$name"), $(sql_quote_or_null "$contact"), $(sql_quote_or_null "$email"), $(sql_quote_or_null "$phone"));
           $(audit_sql CLIENT_CREATED CLIENT "$code" "" NULL "json_object('name',$(sql_quote "$name"))")"
    log INFO "client created code=$code"
    info "Client $code created."
}

client_update() {
    require_perm client.update
    parse_args "name email phone contact active" "$@"; need_pos 1 "client update CODE [--name N ...]"
    local code=${POS[0]}; client_id "$code" >/dev/null
    ((${#OPT[@]} > 0)) || fail "$EX_USAGE" "Nothing to update." "Give at least one option, e.g. --active 0"
    local sets=() k
    for k in "${!OPT[@]}"; do
        valid_text "$k" "${OPT[$k]}" 120
        case $k in
            name)    [[ -n ${OPT[$k]//[[:space:]]/} ]] || fail "$EX_VALIDATION" "Client name must not be blank."
                     sets+=("name = $(sql_quote "${OPT[$k]}")") ;;
            email)   sets+=("contact_email = $(sql_quote_or_null "${OPT[$k]}")") ;;
            phone)   sets+=("contact_phone = $(sql_quote_or_null "${OPT[$k]}")") ;;
            contact) sets+=("contact_name = $(sql_quote_or_null "${OPT[$k]}")") ;;
            active)  valid_enum active "${OPT[$k]}" 0 1; sets+=("active = ${OPT[$k]}") ;;
        esac
    done
    local IFS=,
    local q; q=$(sql_quote "$code")
    db_tx "$(snap_begin "json_object('name',name,'email',contact_email,'phone',contact_phone,'active',active) AS j FROM clients WHERE code=$q")
           UPDATE clients SET ${sets[*]} WHERE code = $q;
           $(audit_sql CLIENT_UPDATED CLIENT "$code" "" "$SNAP_OLD" "(SELECT json_object('name',name,'email',contact_email,'phone',contact_phone,'active',active) FROM clients WHERE code=$q)" "")
           $(snap_end)"
    info "Client $code updated."
}
