#!/usr/bin/env bash
# audit.sh - read the audit trail. Records are written by the other commands (see lib/audit.sh).

readonly AUDIT_COLS="id, ts, username AS user, action, entity, entity_id, sample_code AS sample, old_value, new_value, details"

cmd_audit() {
    db_require; auth_init
    local sub=${1:-}; shift || true
    case $sub in
        list) audit_list "$@" ;;
        show) audit_show "$@" ;;
        *) fail "$EX_USAGE" "Unknown or missing audit action '$sub'." "Try: lab audit list" ;;
    esac
}

audit_list() {
    parse_args "limit action user" "$@"; need_pos 0 "audit list [--limit N --action A --user U]"
    local limit=${OPT[limit]:-50} where="1=1"
    [[ $limit =~ ^[0-9]{1,4}$ ]] || fail "$EX_VALIDATION" "Invalid --limit '$limit'." "Use a whole number up to 9999."
    if [[ -n ${OPT[action]:-} ]]; then [[ ${OPT[action]} =~ ^[A-Z_]+$ ]] || fail "$EX_VALIDATION" "Invalid action."; where+=" AND action = $(sql_quote "${OPT[action]}")"; fi
    if [[ -n ${OPT[user]:-} ]]; then valid_username "${OPT[user]}"; where+=" AND username = $(sql_quote "${OPT[user]}")"; fi
    db_show "SELECT * FROM (SELECT $AUDIT_COLS FROM audit_log WHERE $where ORDER BY id DESC LIMIT $limit) ORDER BY id;"
}

# audit show SAMPLE_ID          everything that happened to a sample (results, requests, status...)
# audit show ENTITY ENTITY_ID   one specific entity, e.g. "audit show TEST PH"
audit_show() {
    parse_args "" "$@"
    local where
    if ((${#POS[@]} == 1)); then
        valid_sample_id "${POS[0]}"
        where="sample_code = $(sql_quote "${POS[0]}") OR (entity = 'SAMPLE' AND entity_id = $(sql_quote "${POS[0]}"))"
    elif ((${#POS[@]} == 2)); then
        local entity=${POS[0]^^}
        valid_enum entity "$entity" SAMPLE RESULT REQUEST TEST CLIENT USER IMPORT SYSTEM
        valid_text id "${POS[1]}" 100
        where="entity = $(sql_quote "$entity") AND entity_id = $(sql_quote "${POS[1]}")"
        [[ $entity != SAMPLE ]] || where="sample_code = $(sql_quote "${POS[1]}") OR (entity = 'SAMPLE' AND entity_id = $(sql_quote "${POS[1]}"))"
    else
        fail "$EX_USAGE" "Wrong number of arguments." "Usage: lab audit show SAMPLE_ID | lab audit show ENTITY ID"
    fi
    db_exists "SELECT count(*) FROM audit_log WHERE $where;" || fail "$EX_NOTFOUND" "No audit records found." "${POS[*]} has no history (or does not exist)."
    db_show "SELECT $AUDIT_COLS FROM audit_log WHERE $where ORDER BY id;"
}
