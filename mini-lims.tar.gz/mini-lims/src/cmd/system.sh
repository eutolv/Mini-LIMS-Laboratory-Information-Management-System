#!/usr/bin/env bash
# system.sh - operations: init, migrations, health, backup, restore, logs.
# Ops commands that must work even when the database is missing or broken (init, health, logs)
# do not require a database identity; filesystem permissions protect them instead.

SYS_TS() { date -u +%Y%m%dT%H%M%SZ; }

cmd_system() {
    local sub=${1:-}; shift || true
    case $sub in
        init)     sys_init "$@" ;;
        migrate)  sys_migrate ;;
        health)   sys_health ;;
        backup)   db_require; auth_init; sys_backup "$@" ;;
        restore)  db_require; auth_init; sys_restore "$@" ;;
        logs)     sys_logs "$@" ;;
        workflow) db_require; auth_init; db_show "SELECT from_status, to_status, allowed_roles FROM workflow_transitions ORDER BY rowid;" ;;
        reset)    sys_reset "$@" ;;
        *) fail "$EX_USAGE" "Unknown or missing system action '$sub'." "Try: lab system health" ;;
    esac
}

sys_dirs() {
    local d
    for d in "$(dirname "$LAB_DB")" "$(dirname "$LAB_LOG_FILE")" "$LAB_BACKUP_DIR"; do
        mkdir -p "$d" || fail "$EX_CONFIG" "Cannot create directory." "$d"
        chmod 700 "$d" 2>/dev/null || true       # lab data may be sensitive: owner-only
    done
}

sys_init() {
    parse_args "seed?" "$@"; need_pos 0 "system init [--seed]"
    command -v sqlite3 >/dev/null || fail "$EX_CONFIG" "sqlite3 is not installed." "Install it, e.g. 'sudo apt install sqlite3'."
    sys_dirs; sys_migrate
    if [[ -n ${OPT[seed]:-} ]]; then
        db_exec "$(<"$LAB_HOME/database/seed.sql")"
        info "Demo data loaded (users: admin, analyst1, reviewer1)."
    fi
    log INFO "system initialised db=$LAB_DB"
    info "Ready. Try: lab client list"
}

# Apply pending migrations in order, each in its own transaction with its version recorded.
sys_migrate() {
    sys_dirs
    db_exec "CREATE TABLE IF NOT EXISTS schema_migrations (version INTEGER PRIMARY KEY, name TEXT NOT NULL, applied_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')));"
    local f base v applied=0
    for f in "$LAB_HOME"/migrations/*.sql; do
        base=$(basename "$f")
        [[ $base =~ ^([0-9]{3})_[a-z0-9_]+\.sql$ ]] || fail "$EX_CONFIG" "Bad migration file name '$base'." "Expected NNN_description.sql"
        v=$((10#${BASH_REMATCH[1]}))
        db_exists "SELECT 1 FROM schema_migrations WHERE version = $v;" && continue
        db_exec "BEGIN IMMEDIATE;
$(<"$f")
INSERT INTO schema_migrations(version, name) VALUES ($v, '${base%.sql}');
COMMIT;"
        info "Applied migration $base"; applied=$((applied + 1)); log INFO "migration applied $base"
    done
    ((applied > 0)) || info "Schema is up to date (version $(db_query 'SELECT MAX(version) FROM schema_migrations;'))."
}

# --------------------------------------------------------------------------- health
HEALTH_WARN=0; HEALTH_DBFAIL=0; HEALTH_SYSFAIL=0
h_ok()   { printf '  [ OK ] %s\n' "$*"; }
h_warn() { printf '  [WARN] %s\n' "$*"; HEALTH_WARN=$((HEALTH_WARN + 1)); }
h_fail() { printf '  [FAIL] %s\n' "$*"; if [[ $1 == db:* ]]; then HEALTH_DBFAIL=$((HEALTH_DBFAIL + 1)); else HEALTH_SYSFAIL=$((HEALTH_SYSFAIL + 1)); fi; }

sys_health() {
    echo "mini-LIMS health check ($(now_utc))"
    # 1. tooling
    if command -v sqlite3 >/dev/null; then
        local ver; ver=$(sqlite3 --version | awk '{print $1}')
        if [[ $(printf '%s\n%s\n' "$MIN_SQLITE" "$ver" | sort -V | head -1) == "$MIN_SQLITE" ]]; then h_ok "sqlite3 $ver"; else h_fail "sqlite3 $ver is older than $MIN_SQLITE"; fi
    else h_fail "sqlite3 is not installed"; fi
    # 2. configuration
    validate_config
    if ((${#CONFIG_ERRORS[@]} == 0)); then h_ok "configuration valid"; else local e; for e in "${CONFIG_ERRORS[@]}"; do h_fail "config: $e"; done; fi
    # 3. directories
    local d
    for d in "$(dirname "$LAB_DB")" "$(dirname "$LAB_LOG_FILE")" "$LAB_BACKUP_DIR"; do
        if [[ -d $d && -w $d ]]; then h_ok "writable: $d"; else h_fail "directory missing or not writable: $d"; fi
    done
    # 4. disk space (warn under 100 MB free)
    if [[ -d $(dirname "$LAB_DB") ]]; then
        local free_kb; free_kb=$(df -Pk "$(dirname "$LAB_DB")" | awk 'NR==2{print $4}')
        if ((free_kb > 102400)); then h_ok "disk space: $((free_kb / 1024)) MB free"; else h_warn "low disk space: $((free_kb / 1024)) MB free"; fi
    fi
    # 5. database
    if [[ ! -f $LAB_DB ]]; then h_fail "db: database not found at $LAB_DB (run: lab system init --seed)"
    elif command -v sqlite3 >/dev/null; then
        local perm; perm=$(stat -c %a "$LAB_DB" 2>/dev/null || echo 000)
        if [[ ${perm: -1} == 0 ]]; then h_ok "database file permissions $perm"; else h_warn "database is accessible by other users (mode $perm); consider chmod 600"; fi
        local ic; ic=$(sqlite3 "$LAB_DB" 'PRAGMA integrity_check;' 2>&1 | head -1)
        if [[ $ic == ok ]]; then h_ok "integrity_check: ok"; else h_fail "db: integrity_check: $ic"; fi
        local fk; fk=$(sqlite3 "$LAB_DB" 'PRAGMA foreign_key_check;' 2>&1 | head -1)
        if [[ -z $fk ]]; then h_ok "foreign keys consistent"; else h_fail "db: foreign key violations found"; fi
        local have latest; have=$(sqlite3 "$LAB_DB" 'SELECT COALESCE(MAX(version),0) FROM schema_migrations;' 2>/dev/null || echo 0)
        latest=$(ls "$LAB_HOME"/migrations/*.sql 2>/dev/null | wc -l)
        if ((have == latest)); then h_ok "schema version $have (current)"; else h_warn "schema version $have, $latest available: run 'lab system migrate'"; fi
    fi
    # 6. backups
    local newest; newest=$(find "$LAB_BACKUP_DIR" -maxdepth 1 -name 'lims-*.db' -printf '%T@ %p\n' 2>/dev/null | sort -rn | head -1 | cut -d' ' -f2-)
    if [[ -z $newest ]]; then h_warn "no backups found in $LAB_BACKUP_DIR"
    else
        local age_h=$(( ($(date +%s) - $(stat -c %Y "$newest")) / 3600 ))
        if [[ $(sqlite3 "$newest" 'PRAGMA integrity_check;' 2>&1 | head -1) == ok ]]; then
            if ((age_h <= 48)); then h_ok "latest backup verified, ${age_h}h old ($(basename "$newest"))"; else h_warn "latest backup is ${age_h}h old"; fi
        else h_fail "latest backup FAILS integrity check: $newest"; fi
    fi
    echo
    if ((HEALTH_SYSFAIL + HEALTH_DBFAIL > 0)); then
        echo "Result: UNHEALTHY"; log ERROR "health check failed sys=$HEALTH_SYSFAIL db=$HEALTH_DBFAIL"
        ((HEALTH_DBFAIL > 0)) && exit "$EX_DATABASE"; exit "$EX_CONFIG"
    elif ((HEALTH_WARN > 0)); then echo "Result: OK with $HEALTH_WARN warning(s)"; log WARNING "health warnings=$HEALTH_WARN"; exit 1
    fi
    echo "Result: HEALTHY"; log INFO "health check ok"
}

# --------------------------------------------------------------------------- backup / restore
# Uses sqlite's online .backup: a consistent snapshot even while other processes write
# (a plain `cp` of a live database can copy a half-written file).
sys_backup() {
    require_perm system.backup
    parse_args "" "$@"; need_pos 0 "system backup"
    sys_dirs
    [[ $LAB_BACKUP_DIR != *"'"* ]] || fail "$EX_CONFIG" "LAB_BACKUP_DIR must not contain a single quote."
    local ts final tmp; ts=$(SYS_TS)
    final="$LAB_BACKUP_DIR/lims-$ts.db"; tmp="$final.partial"
    [[ ! -e $final ]] || fail "$EX_CONFLICT" "A backup for this second already exists." "$final"
    db_exec ".backup '$tmp'"
    # Verify BEFORE publishing: a backup that was never checked is a hope, not a backup.
    if [[ $(sqlite3 "$tmp" 'PRAGMA integrity_check;' | head -1) != ok ]]; then rm -f "$tmp"; fail "$EX_DATABASE" "Backup verification failed." "The partial file was removed."; fi
    chmod 600 "$tmp"; mv "$tmp" "$final"
    (cd "$LAB_BACKUP_DIR" && sha256sum "lims-$ts.db" >"lims-$ts.db.sha256")
    db_tx "$(audit_sql SYSTEM_BACKUP SYSTEM "lims-$ts.db" "" NULL NULL "verified")"
    # Retention: delete backups older than N days (never the one we just made).
    find "$LAB_BACKUP_DIR" -maxdepth 1 -name 'lims-*.db*' -mtime +"$LAB_BACKUP_RETENTION_DAYS" -delete 2>/dev/null || true
    log INFO "backup created file=lims-$ts.db"
    info "Backup created and verified: $final"
}

sys_restore() {
    require_perm system.restore
    parse_args "yes?" "$@"; need_pos 1 "system restore BACKUP_FILE --yes"
    [[ -n ${OPT[yes]:-} ]] || fail "$EX_USAGE" "Restore replaces the current database." "Re-run with --yes to confirm."
    local input=${POS[0]} file real
    # Only files inside the backup directory may be restored (blocks path traversal like ../../etc/x).
    case $input in */*) file=$input ;; *) file="$LAB_BACKUP_DIR/$input" ;; esac
    real=$(readlink -f -- "$file" 2>/dev/null) || real=""
    [[ -f $real ]] || fail "$EX_NOTFOUND" "Backup file not found." "$input"
    [[ $real == "$(readlink -f -- "$LAB_BACKUP_DIR")"/* ]] || fail "$EX_VALIDATION" "Refusing to restore from outside the backup directory." "$LAB_BACKUP_DIR"
    if [[ -f $real.sha256 ]]; then
        (cd "$(dirname "$real")" && sha256sum --status -c "$(basename "$real").sha256") || fail "$EX_DATABASE" "Checksum mismatch." "The backup file is corrupted or was modified."
    fi
    [[ $(sqlite3 "$real" 'PRAGMA integrity_check;' 2>&1 | head -1) == ok ]] || fail "$EX_DATABASE" "Backup fails integrity check." "$real"
    [[ $(sqlite3 "$real" "SELECT count(*) FROM sqlite_master WHERE name IN ('samples','audit_log','schema_migrations');" 2>&1) == 3 ]] \
        || fail "$EX_VALIDATION" "File is not a mini-LIMS database." "$real"
    local safety="$LAB_BACKUP_DIR/pre-restore-$(SYS_TS).db"       # can always undo the restore
    db_exec ".backup '$safety'"; chmod 600 "$safety"
    cp -- "$real" "$LAB_DB.restore.tmp" && chmod 600 "$LAB_DB.restore.tmp" && mv -f -- "$LAB_DB.restore.tmp" "$LAB_DB"
    rm -f -- "$LAB_DB-wal" "$LAB_DB-shm" "$LAB_DB-journal"
    db_exec "$(audit_sql SYSTEM_RESTORE SYSTEM "$(basename "$real")" "" NULL NULL "previous database saved as $(basename "$safety")")" || true
    log WARNING "database restored from $(basename "$real")"
    info "Restored from $(basename "$real"). Previous database saved as $safety"
}

sys_reset() {
    parse_args "yes?" "$@"; need_pos 0 "system reset --yes"
    [[ -n ${OPT[yes]:-} ]] || fail "$EX_USAGE" "Reset deletes ALL data and reloads the demo data." "Re-run with --yes to confirm."
    if [[ -f $LAB_DB ]]; then
        sys_dirs; cp -- "$LAB_DB" "$LAB_BACKUP_DIR/pre-reset-$(SYS_TS).db"; rm -f -- "$LAB_DB" "$LAB_DB-wal" "$LAB_DB-shm"
    fi
    log WARNING "database reset"
    OPT=(); sys_init --seed
}

# --------------------------------------------------------------------------- logs
sys_logs() {
    parse_args "lines level" "$@"; need_pos 0 "system logs [--lines N] [--level INFO|WARNING|ERROR]"
    local n=${OPT[lines]:-30}
    [[ $n =~ ^[0-9]{1,5}$ ]] || fail "$EX_VALIDATION" "Invalid --lines '$n'."
    [[ -f $LAB_LOG_FILE ]] || fail "$EX_NOTFOUND" "No log file yet." "$LAB_LOG_FILE"
    if [[ -n ${OPT[level]:-} ]]; then
        valid_enum level "${OPT[level]}" INFO WARNING ERROR
        grep -E " ${OPT[level]} +user=" "$LAB_LOG_FILE" | tail -n "$n" || true
    else tail -n "$n" "$LAB_LOG_FILE"; fi
}
