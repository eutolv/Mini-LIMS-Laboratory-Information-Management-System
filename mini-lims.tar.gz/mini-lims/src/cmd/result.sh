#!/usr/bin/env bash
# result.sh - entering, correcting and showing results.
# Flagging (NORMAL/LOW/HIGH/INVALID) is computed by the database from the test's specification.

# result_validate SAMPLE TEST VALUE UNIT
# Non-fatal validation shared by 'result add/update' and by the CSV import (which must keep going
# after a bad row). Returns 1 and sets R_ERR_CODE/R_ERR_HEAD/R_ERR_REASON on failure; on success
# sets R_DATATYPE, R_UNIT, R_SAMPLE_STATUS, R_HAS_RESULT.
result_validate() {
    local sample=$1 test=$2 value=$3 unit=$4 qs qt row requested
    R_ERR_CODE=$EX_VALIDATION; R_ERR_HEAD=""; R_ERR_REASON=""
    if [[ ! $sample =~ $RE_SAMPLE ]]; then R_ERR_HEAD="Invalid sample ID '$sample'."; R_ERR_REASON="Expected format SAM-0001."; return 1; fi
    if [[ ! $test =~ $RE_TEST ]]; then R_ERR_HEAD="Invalid test code '$test'."; R_ERR_REASON="Use upper-case letters, digits, underscore."; return 1; fi
    qs=$(sql_quote "$sample"); qt=$(sql_quote "$test")
    db_exists "SELECT 1 FROM samples WHERE code = $qs;" || { R_ERR_CODE=$EX_NOTFOUND; R_ERR_HEAD="Sample '$sample' does not exist."; return 1; }
    db_exists "SELECT 1 FROM tests WHERE code = $qt;"   || { R_ERR_CODE=$EX_NOTFOUND; R_ERR_HEAD="Test '$test' does not exist."; return 1; }
    row=$(db_query "SELECT s.status, t.datatype,
        EXISTS (SELECT 1 FROM test_requests tr WHERE tr.sample_id = s.id AND tr.test_id = t.id),
        EXISTS (SELECT 1 FROM test_requests tr JOIN results r ON r.request_id = tr.id WHERE tr.sample_id = s.id AND tr.test_id = t.id)
        FROM samples s, tests t WHERE s.code = $qs AND t.code = $qt;")
    IFS='|' read -r R_SAMPLE_STATUS R_DATATYPE requested R_HAS_RESULT <<<"$row"
    R_UNIT=$(db_query "SELECT COALESCE(unit,'') FROM tests WHERE code = $qt;")
    if ((requested == 0)); then
        R_ERR_CODE=$EX_CONFLICT; R_ERR_HEAD="Test $test was not requested for sample $sample."; R_ERR_REASON="Run: lab request create $sample $test"; return 1
    fi
    if [[ -z $value ]]; then R_ERR_HEAD="Result value must not be empty."; return 1; fi
    if [[ $value =~ [[:cntrl:]] || ${#value} -gt 200 ]]; then R_ERR_HEAD="Invalid result value."; R_ERR_REASON="No control characters, max 200 characters."; return 1; fi
    if [[ $R_DATATYPE == NUMERIC && ! $value =~ $RE_NUMBER ]]; then
        R_ERR_HEAD="Invalid result value '$value'."; R_ERR_REASON="Test $test is NUMERIC; expected a number such as 7.42."; return 1
    fi
    if [[ -n $unit && $unit != "$R_UNIT" ]]; then
        R_ERR_HEAD="Unit mismatch for $test."; R_ERR_REASON="Given '$unit', test is configured for '${R_UNIT:-no unit}'."; return 1
    fi
    return 0
}

# result_context : fatal wrapper used by the interactive commands.
result_context() {
    result_validate "$@" || fail "$R_ERR_CODE" "$R_ERR_HEAD" "$R_ERR_REASON"
}

# result_insert_sql SAMPLE TEST VALUE : the SQL (insert + audit + automatic status change) for ONE
# new result. Requires a successful result_validate first. Shared by 'result add' and 'import'.
result_insert_sql() {
    local sample=$1 test=$2 value=$3 qs qt vt vn
    qs=$(sql_quote "$sample"); qt=$(sql_quote "$test"); vt=$(sql_quote "$value")
    if [[ $R_DATATYPE == NUMERIC ]]; then vn="CAST($vt AS REAL)"; else vn="NULL"; fi
    cat <<SQL
INSERT INTO results(request_id, value_text, value_num, unit, analyst)
  SELECT tr.id, $vt, $vn, $(sql_quote_or_null "$R_UNIT"), $(sql_quote "$LAB_USER_NAME")
  FROM test_requests tr JOIN samples s ON s.id = tr.sample_id JOIN tests t ON t.id = tr.test_id
  WHERE s.code = $qs AND t.code = $qt;
$(audit_sql RESULT_CREATED RESULT "$sample/$test" "$sample" NULL "(SELECT $RESULT_JSON $(result_by_ids "$sample" "$test"))" "$RESULT_AUDIT_NOTE")
UPDATE samples SET status = 'IN_TESTING', updated_at = strftime('%Y-%m-%dT%H:%M:%SZ','now') WHERE code = $qs AND status = 'REGISTERED';
$(AUDIT_WHEN='changes() > 0' audit_sql STATUS_CHANGED SAMPLE "$sample" "$sample" "json_object('status','REGISTERED')" "json_object('status','IN_TESTING')" 'automatic: first result entered')
SQL
}

readonly RESULT_JSON="json_object('value',r.value_text,'unit',r.unit,'flag',r.flag,'status',r.status)"
result_by_ids() { # rows of results for SAMPLE/TEST (sql fragment)
    printf "FROM results r JOIN test_requests tr ON tr.id = r.request_id JOIN samples s ON s.id = tr.sample_id JOIN tests t ON t.id = tr.test_id WHERE s.code = %s AND t.code = %s" "$(sql_quote "$1")" "$(sql_quote "$2")"
}

cmd_result() {
    db_require; auth_init
    local sub=${1:-}; shift || true
    case $sub in
        add)    result_add "$@" ;;
        update) result_update "$@" ;;
        show)   parse_args "" "$@"; need_pos 1 "result show SAMPLE_ID"
                sample_status_of "${POS[0]}" >/dev/null
                db_show "SELECT test, value, unit, flag, result_status AS status, analyst, entered_at FROM v_sample_results WHERE sample = $(sql_quote "${POS[0]}") ORDER BY test;" ;;
        *) fail "$EX_USAGE" "Unknown or missing result action '$sub'." "Try: lab result add SAM-0001 PH 7.42" ;;
    esac
}

result_add() {
    require_perm result.add
    parse_args "unit" "$@"; need_pos 3 "result add SAMPLE_ID TEST_CODE VALUE [--unit U]"
    local sample=${POS[0]} test=${POS[1]} value=${POS[2]} flag
    result_context "$sample" "$test" "$value" "${OPT[unit]:-}"
    ((R_HAS_RESULT == 0)) || fail "$EX_CONFLICT" "Cannot add result." "$test already has a result for $sample. Use: lab result update $sample $test VALUE --reason TEXT"
    RESULT_AUDIT_NOTE=""
    flag=$(db_tx "$(result_insert_sql "$sample" "$test" "$value")
                  SELECT r.flag $(result_by_ids "$sample" "$test");")
    log INFO "result added sample=$sample test=$test flag=$flag"
    info "Result recorded: $sample $test = $value ${R_UNIT}  [$flag]"
    [[ $flag == NORMAL ]] || info "Note: result flagged $flag."
}

result_update() {
    require_perm result.update
    parse_args "unit reason" "$@"; need_pos 3 "result update SAMPLE_ID TEST_CODE VALUE --reason TEXT"
    local sample=${POS[0]} test=${POS[1]} value=${POS[2]} reason=${OPT[reason]:-}
    [[ -n ${reason//[[:space:]]/} ]] || fail "$EX_VALIDATION" "A reason is required to change a result." "Add: --reason \"why\""
    valid_text reason "$reason" 300
    result_context "$sample" "$test" "$value" "${OPT[unit]:-}"
    ((R_HAS_RESULT == 1)) || fail "$EX_NOTFOUND" "Cannot update result." "$test has no result for $sample yet. Use: lab result add"
    local from; from=$(result_by_ids "$sample" "$test")
    local vt vn
    vt=$(sql_quote "$value"); if [[ $R_DATATYPE == NUMERIC ]]; then vn="CAST($vt AS REAL)"; else vn="NULL"; fi
    local out
    out=$(db_tx "$(snap_begin "$RESULT_JSON AS j $from")
                 UPDATE results SET value_text = $vt, value_num = $vn
                  WHERE request_id = (SELECT tr.id FROM test_requests tr JOIN samples s ON s.id = tr.sample_id JOIN tests t ON t.id = tr.test_id
                                      WHERE s.code = $(sql_quote "$sample") AND t.code = $(sql_quote "$test"));
                 SELECT r.flag $from;
                 $(audit_sql RESULT_UPDATED RESULT "$sample/$test" "$sample" "$SNAP_OLD" "(SELECT $RESULT_JSON $from)" "reason: $reason")
                 $(snap_end)")
    log INFO "result updated sample=$sample test=$test flag=$out"
    info "Result updated: $sample $test = $value ${R_UNIT}  [$out]"
}
