#!/usr/bin/env bash
# config.sh - load configuration WITHOUT executing it.
# Why not `source config/lims.conf`? Sourcing runs arbitrary shell: a writable config file
# would become a code-execution vector. Instead we parse KEY=VALUE lines against a whitelist.

readonly CONFIG_KEYS=" LAB_DB LAB_LOG_FILE LAB_BACKUP_DIR LAB_BACKUP_RETENTION_DAYS LAB_DEFAULT_USER LAB_API_HOST LAB_API_PORT "

load_config_file() {
    local file=$1 line key val
    [[ -f $file ]] || return 0
    while IFS= read -r line || [[ -n $line ]]; do
        line=${line%%#*}                      # strip comments
        [[ $line =~ ^[[:space:]]*([A-Z_]+)=(.*)$ ]] || continue
        key=${BASH_REMATCH[1]}; val=${BASH_REMATCH[2]}
        val=${val%"${val##*[![:space:]]}"}    # trim trailing whitespace
        [[ $CONFIG_KEYS == *" $key "* ]] || { CONFIG_ERRORS+=("unknown key '$key' in $file"); continue; }
        [[ -n ${!key+x} ]] && continue        # environment wins over files
        printf -v "$key" '%s' "$val"
        export "${key?}"
    done <"$file"
}

# Resolve a possibly relative path against LAB_HOME.
abs_path() { case $1 in /*) printf '%s' "$1" ;; *) printf '%s/%s' "$LAB_HOME" "$1" ;; esac; }

CONFIG_ERRORS=()

load_config() {
    load_config_file "$LAB_HOME/config/local.conf"   # local first: first definition wins
    load_config_file "${LAB_CONFIG:-$LAB_HOME/config/lims.conf}"
    LAB_DB=$(abs_path "${LAB_DB:-data/lims.db}")
    LAB_LOG_FILE=$(abs_path "${LAB_LOG_FILE:-logs/lims.log}")
    LAB_BACKUP_DIR=$(abs_path "${LAB_BACKUP_DIR:-backups}")
    LAB_BACKUP_RETENTION_DAYS=${LAB_BACKUP_RETENTION_DAYS:-14}
    LAB_DEFAULT_USER=${LAB_DEFAULT_USER:-admin}
    export LAB_DB LAB_LOG_FILE LAB_BACKUP_DIR LAB_BACKUP_RETENTION_DAYS LAB_DEFAULT_USER
}

# validate_config : appends problems to CONFIG_ERRORS (used by 'system health').
validate_config() {
    [[ $LAB_BACKUP_RETENTION_DAYS =~ ^[0-9]+$ ]] || CONFIG_ERRORS+=("LAB_BACKUP_RETENTION_DAYS must be a whole number")
    [[ $LAB_DEFAULT_USER =~ $RE_USER ]] || CONFIG_ERRORS+=("LAB_DEFAULT_USER is not a valid username")
    [[ ${LAB_API_PORT:-8080} =~ ^[0-9]+$ ]] || CONFIG_ERRORS+=("LAB_API_PORT must be a number")
    return 0
}
