#!/usr/bin/env bash
# auth.sh - identity + role-based permissions.
# IMPORTANT LIMITATION: identity comes from $LAB_USER (or --user). There is NO password.
# This teaches the role model; it is not authentication. See docs/ARCHITECTURE.md.

LAB_USER_NAME=""
LAB_USER_ROLE=""

# Permission matrix: action -> roles allowed. Reads need no permission beyond being an active user.
declare -A PERMS=(
    [client.create]="ADMIN"
    [client.update]="ADMIN"
    [test.create]="ADMIN"
    [test.update]="ADMIN"
    [user.create]="ADMIN"
    [user.update]="ADMIN"
    [sample.create]="ADMIN ANALYST"
    [sample.update]="ADMIN ANALYST"
    [sample.delete]="ADMIN"
    [request.create]="ADMIN ANALYST"
    [result.add]="ADMIN ANALYST"
    [result.update]="ADMIN ANALYST"
    [import.run]="ADMIN ANALYST"
    [system.backup]="ADMIN"
    [system.restore]="ADMIN"
)

# auth_init : resolve the acting user from the database. Must be an existing, active user.
auth_init() {
    local name=${LAB_USER:-$LAB_DEFAULT_USER} row
    valid_username "$name"
    row=$(db_query "SELECT role, active FROM users WHERE username = $(sql_quote "$name");")
    [[ -n $row ]] || fail "$EX_PERMISSION" "Unknown user '$name'." "Set LAB_USER to an existing username (see: lab user list)."
    [[ ${row#*|} == 1 ]] || fail "$EX_PERMISSION" "User '$name' is inactive."
    LAB_USER_NAME=$name
    LAB_USER_ROLE=${row%|*}
}

# require_perm ACTION : fail with exit 6 unless the current role may perform ACTION.
require_perm() {
    local action=$1 role
    for role in ${PERMS[$action]:-}; do [[ $role == "$LAB_USER_ROLE" ]] && return 0; done
    fail "$EX_PERMISSION" "Permission denied." "Role $LAB_USER_ROLE may not perform '$action' (user: $LAB_USER_NAME)."
}
