#!/usr/bin/env bash
# db.sh - the ONLY place that talks to sqlite3.
# All SQL is passed on stdin (not on the command line) so it never shows in `ps` output.

readonly MIN_SQLITE="3.33.0"     # -json and -box output modes

db_require() {
    command -v sqlite3 >/dev/null 2>&1 || fail "$EX_CONFIG" "sqlite3 is not installed." "Install it, e.g. 'sudo apt install sqlite3'."
    [[ -f $LAB_DB ]] || fail "$EX_DATABASE" "Database not found." "Expected $LAB_DB. Run: lab system init --seed"
}

# db_fail MESSAGE : translate a sqlite error into a friendly message + exit code.
db_fail() {
    local msg=$1 rule
    log ERROR "sqlite: ${msg//$'\n'/ }"
    if [[ $msg == *"RULE: "* ]]; then
        rule=${msg#*RULE: }; rule=${rule%% (*}
        fail "$EX_CONFLICT" "Business rule violated." "$rule."
    elif [[ $msg == *"UNIQUE constraint failed"* ]]; then
        rule=${msg#*UNIQUE constraint failed: }; rule=${rule%% (*}
        fail "$EX_CONFLICT" "Duplicate record." "A record with the same $rule already exists."
    elif [[ $msg == *"FOREIGN KEY constraint failed"* ]]; then
        fail "$EX_CONFLICT" "Referenced record is missing or still in use." "Foreign key constraint failed."
    elif [[ $msg == *"CHECK constraint failed"* ]]; then
        rule=${msg#*CHECK constraint failed: }; rule=${rule%% (*}
        fail "$EX_VALIDATION" "Value rejected by the database." "CHECK constraint failed: $rule."
    elif [[ $msg == *"locked"* || $msg == *"busy"* ]]; then
        fail "$EX_DATABASE" "Database is busy." "Another process holds a lock. Retry in a moment."
    else
        fail "$EX_DATABASE" "Database error." "${msg%%$'\n'*}"
    fi
}

# db_exec SQL [sqlite3 options...] : run SQL, print its output, map failures via db_fail.
db_exec() {
    local sql=$1; shift
    local out="" rc=0 errf
    errf=$(mktemp "${TMPDIR:-/tmp}/lab-err.XXXXXX")     # mktemp creates the file mode 0600
    out=$(printf '%s\n' "$sql" | sqlite3 -bail "$@" -cmd '.timeout 5000' -cmd 'PRAGMA foreign_keys=ON;' "$LAB_DB" 2>"$errf") || rc=$?
    if ((rc != 0)); then
        local emsg; emsg=$(<"$errf"); rm -f "$errf"
        db_fail "$emsg"
    fi
    rm -f "$errf"
    if [[ -n $out ]]; then printf '%s\n' "$out"; fi
    return 0
}

# db_query SQL : one value / pipe-separated rows, no headers. For use inside $( ).
db_query() { db_exec "$1" -separator '|'; }

# db_tx SQL : run SQL inside ONE transaction. Either everything commits or nothing does.
# BEGIN IMMEDIATE takes the write lock up front so we fail fast instead of deadlocking.
db_tx() { db_exec "BEGIN IMMEDIATE;
$1
COMMIT;"; }

# db_show SQL : print a result set for humans (box table) or machines (JSON) per LAB_FORMAT.
db_show() {
    if [[ $LAB_FORMAT == json ]]; then db_exec "$1" -json; else db_exec "$1" -header -box; fi
}

# db_exists SQL : true if the query returns a non-empty, non-zero first value.
db_exists() { local v; v=$(db_query "$1"); [[ -n $v && $v != 0 ]]; }
