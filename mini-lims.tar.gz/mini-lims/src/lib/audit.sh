#!/usr/bin/env bash
# audit.sh - build audit INSERT statements that are appended to the SAME transaction as the change.
# If the change rolls back, so does its audit row; if it commits, the audit row is guaranteed to exist.

# _aq VALUE : quote VALUE as SQL text, unless it starts with '@' (then the rest is a raw SQL
# expression written by our own code, e.g. "@(SELECT code FROM samples WHERE ...)").
_aq() { if [[ ${1:-} == @* ]]; then printf '%s' "${1#@}"; else sql_quote_or_null "${1:-}"; fi; }

# audit_sql ACTION ENTITY ENTITY_ID SAMPLE_CODE OLD_SQL NEW_SQL DETAILS
#   ENTITY_ID / SAMPLE_CODE may be raw SQL via the '@' prefix (see _aq).
#   OLD_SQL / NEW_SQL are SQL *expressions* built by our own code (NULL, or a json_object(...)
#   subquery). They must never contain raw user input: user text goes through sql_quote first.
#   Set AUDIT_WHEN="<sql condition>" in front of the call to make the audit row conditional
#   (e.g. AUDIT_WHEN="changes() > 0" right after an UPDATE that may have matched no row).
audit_sql() {
    local action=$1 entity=$2 entity_id=$3 sample=${4:-} old=${5:-NULL} new=${6:-NULL} details=${7:-}
    printf "INSERT INTO audit_log(username, action, entity, entity_id, sample_code, old_value, new_value, details) SELECT %s,%s,%s,%s,%s,%s,%s,%s WHERE %s;\n" \
        "$(sql_quote "$LAB_USER_NAME")" "$(sql_quote "$action")" "$(sql_quote "$entity")" \
        "$(_aq "$entity_id")" "$(_aq "$sample")" "$old" "$new" "$(_aq "$details")" "${AUDIT_WHEN:-1}"
}

# Capturing the "before" picture: snapshot the old state into a TEMP table (per-connection, so it
# lives and dies inside the same transaction), run the change, then reference it as $SNAP_OLD.
#   snap_begin "json_object(...) FROM samples WHERE ..."   ... UPDATE ...   audit_sql ... "$SNAP_OLD" ...   snap_end
readonly SNAP_OLD='(SELECT j FROM temp._snap)'
snap_begin() { printf 'DROP TABLE IF EXISTS temp._snap;\nCREATE TEMP TABLE _snap AS SELECT %s;\n' "$1"; }
snap_end()   { printf 'DROP TABLE IF EXISTS temp._snap;\n'; }
