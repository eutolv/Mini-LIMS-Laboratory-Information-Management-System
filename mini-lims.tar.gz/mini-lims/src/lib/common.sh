#!/usr/bin/env bash
# common.sh - exit codes, logging, error reporting, input validation, option parsing.
# Sourced by bin/lab; never executed directly.

# --- Exit codes: part of the CLI contract (scripts and the REST API depend on them) ---
readonly EX_OK=0 EX_GENERAL=1 EX_USAGE=2 EX_VALIDATION=3 EX_NOTFOUND=4
readonly EX_CONFLICT=5 EX_PERMISSION=6 EX_DATABASE=7 EX_CONFIG=8

LAB_CMDLINE=""          # e.g. "sample create". Only command NAMES are logged, never argument values.
LAB_FORMAT="${LAB_FORMAT:-table}"   # table | json

now_utc() { date -u +%Y-%m-%dT%H:%M:%SZ; }

# log LEVEL message... : append one line to the application log. Never fails the command.
log() {
    local level=$1; shift
    local msg="$*"
    msg=${msg//$'\n'/ }
    [[ -n "${LAB_LOG_FILE:-}" ]] || return 0
    mkdir -p "$(dirname "$LAB_LOG_FILE")" 2>/dev/null || return 0
    printf '%s %-7s user=%s cmd="%s" %s\n' "$(now_utc)" "$level" "${LAB_USER_NAME:-unknown}" \
        "$LAB_CMDLINE" "$msg" >>"$LAB_LOG_FILE" 2>/dev/null || true
}

# fail CODE HEADLINE [REASON] : print a structured error to stderr, log it, exit with CODE.
fail() {
    local code=$1 headline=$2 reason=${3:-}
    {
        printf 'ERROR: %s\n' "$headline"
        if [[ -n $reason ]]; then printf 'Reason: %s\n' "$reason"; fi
        printf 'Exit code: %d\n' "$code"
    } >&2
    local level=WARNING
    ((code == EX_GENERAL || code == EX_DATABASE || code == EX_CONFIG)) && level=ERROR
    log "$level" "exit=$code headline=\"$headline\" reason=\"$reason\""
    exit "$code"
}

info() { printf '%s\n' "$*"; }

# --- Option parsing -------------------------------------------------------------------
declare -A OPT=()
POS=()

# parse_args "opt1 flag2?" "$@" : fills OPT[name]=value for --name value (or =1 for boolean
# flags written "name?"), POS[] for the rest.
# Rejects unknown options so typos cannot be silently ignored.
parse_args() {
    local allowed=" $1 "; shift
    OPT=(); POS=()
    local k
    while (($#)); do
        case $1 in
            --) shift; while (($#)); do POS+=("$1"); shift; done ;;
            --*)
                k=${1#--}
                if [[ $allowed == *" $k? "* ]]; then OPT[$k]=1; shift; continue; fi   # boolean flag
                [[ $allowed == *" $k "* ]] || fail "$EX_USAGE" "Unknown option '--$k'." "Allowed: ${allowed// / --}"
                (($# >= 2)) || fail "$EX_USAGE" "Option '--$k' requires a value."
                OPT[$k]=$2; shift 2 ;;
            *) POS+=("$1"); shift ;;
        esac
    done
}

# need_pos COUNT USAGE : require exactly COUNT positional arguments.
need_pos() {
    local n=$1 usage=$2
    ((${#POS[@]} == n)) || fail "$EX_USAGE" "Wrong number of arguments." "Usage: lab $usage"
}

# --- SQL quoting ----------------------------------------------------------------------
# sql_quote VALUE -> 'VALUE' with single quotes doubled. This is the ONLY way user text enters SQL.
# Values that are numbers must first pass valid_number, and are then inserted unquoted.
sql_quote() { local s=${1//\'/\'\'}; printf "'%s'" "$s"; }
sql_quote_or_null() { if [[ -z ${1:-} ]]; then printf 'NULL'; else sql_quote "$1"; fi; }

# --- Validators (each fails with EX_VALIDATION) ---------------------------------------
readonly RE_SAMPLE='^SAM-[0-9]{4,}$'
readonly RE_TEST='^[A-Z][A-Z0-9_]{1,19}$'
readonly RE_CLIENT='^[A-Z][A-Z0-9_]{1,15}$'
readonly RE_USER='^[a-z][a-z0-9_]{2,31}$'
readonly RE_NUMBER='^-?[0-9]+(\.[0-9]+)?$'
readonly RE_DATE='^[0-9]{4}-[0-9]{2}-[0-9]{2}$'

valid_sample_id() { [[ ${1:-} =~ $RE_SAMPLE ]] || fail "$EX_VALIDATION" "Invalid sample ID '${1:-}'." "Expected format SAM-0001."; }
valid_test_code() { [[ ${1:-} =~ $RE_TEST ]] || fail "$EX_VALIDATION" "Invalid test code '${1:-}'." "Use upper-case letters, digits, underscore (2-20 chars)."; }
valid_client_code() { [[ ${1:-} =~ $RE_CLIENT ]] || fail "$EX_VALIDATION" "Invalid client code '${1:-}'." "Use upper-case letters, digits, underscore (2-16 chars)."; }
valid_username() { [[ ${1:-} =~ $RE_USER ]] || fail "$EX_VALIDATION" "Invalid username '${1:-}'." "Use lower-case letters, digits, underscore (3-32 chars)."; }
valid_number() { [[ ${2:-} =~ $RE_NUMBER ]] || fail "$EX_VALIDATION" "Invalid number for $1: '${2:-}'."; }

# valid_date FIELD VALUE : YYYY-MM-DD and a real calendar date (rejects 2026-02-31).
valid_date() {
    local field=$1 v=${2:-}
    [[ $v =~ $RE_DATE ]] || fail "$EX_VALIDATION" "Invalid $field '$v'." "Expected YYYY-MM-DD."
    local back; back=$(date -u -d "$v" +%F 2>/dev/null) || back=""
    [[ $back == "$v" ]] || fail "$EX_VALIDATION" "Invalid $field '$v'." "Not a real calendar date."
}

# valid_text FIELD VALUE [MAXLEN] : no control characters (protects logs and terminals), bounded length.
valid_text() {
    local field=$1 v=${2:-} max=${3:-500}
    [[ $v =~ [[:cntrl:]] ]] && fail "$EX_VALIDATION" "Invalid $field." "Control characters are not allowed."
    ((${#v} <= max)) || fail "$EX_VALIDATION" "Invalid $field." "Longer than $max characters."
    return 0
}

valid_enum() { # valid_enum FIELD VALUE opt1 opt2 ...
    local field=$1 v=$2; shift 2
    local o; for o in "$@"; do [[ $v == "$o" ]] && return 0; done
    fail "$EX_VALIDATION" "Invalid $field '$v'." "Allowed: $*"
}

valid_json() { # relies on SQLite's json_valid so we do not need jq
    local v=$1
    [[ $(db_query "SELECT json_valid($(sql_quote "$v"));") == 1 ]] || fail "$EX_VALIDATION" "Invalid metadata." "Must be valid JSON, e.g. '{\"site\":\"well 3\"}'."
}

today() { date -u +%F; }
