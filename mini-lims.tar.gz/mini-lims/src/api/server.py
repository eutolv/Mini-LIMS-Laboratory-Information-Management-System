#!/usr/bin/env python3
"""mini-LIMS REST API.

Design decision: this server contains NO business rules and NO SQL. Every request is translated
into a call to bin/lab (argument LIST, never a shell string), so the CLI and the API can never
disagree about validation, workflow, permissions or auditing. The cost is one process per request:
fine for learning, not for load.

Standard library only (http.server, subprocess, json) - nothing to install.
Identity: X-Lab-User header (no password; see docs/API.md and docs/SECURITY.md).
"""
import json, os, re, subprocess, sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
LAB = os.path.join(ROOT, "bin", "lab")
MAX_BODY = 64 * 1024

# CLI exit code -> HTTP status
HTTP_FOR_EXIT = {2: 400, 3: 422, 4: 404, 5: 409, 6: 403, 7: 503, 8: 500}

SAMPLE_ID = re.compile(r"^SAM-[0-9]{4,}$")
TEST_CODE = re.compile(r"^[A-Z][A-Z0-9_]{1,19}$")
ENTITIES = {"sample", "result", "request", "test", "client", "user", "import", "system"}


def run_lab(args, user=None):
    """Run the CLI. args is a list, so there is no shell and no quoting problem."""
    env = dict(os.environ)
    env.pop("LAB_USER", None)
    if user:
        env["LAB_USER"] = user
    p = subprocess.run([LAB, "--json"] + args, capture_output=True, text=True, env=env, timeout=60)
    return p.returncode, p.stdout, p.stderr


def parse_error(stderr, code):
    lines = [l for l in stderr.splitlines() if l and not l.startswith("Exit code")]
    error = lines[0].removeprefix("ERROR: ") if lines else "Unexpected error"
    reason = next((l.removeprefix("Reason: ") for l in lines if l.startswith("Reason: ")), None)
    return {"error": error, "reason": reason, "exit_code": code}


def rows(stdout):
    stdout = stdout.strip()
    return json.loads(stdout) if stdout else []       # sqlite prints nothing for zero rows


class Api(BaseHTTPRequestHandler):
    server_version = "mini-lims/1.0"

    def log_message(self, fmt, *a):       # keep stdout quiet; the CLI writes the audit/app logs
        pass

    # ---- helpers
    def send(self, status, payload):
        body = json.dumps(payload, indent=2).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def cli(self, args, ok_status=200, transform=None):
        code, out, err = run_lab(args, self.headers.get("X-Lab-User"))
        if code != 0:
            return self.send(HTTP_FOR_EXIT.get(code, 500), parse_error(err, code))
        data = rows(out)
        self.send(ok_status, transform(data) if transform else data)

    def body(self, allowed, required=()):
        """Parse a JSON object body, whitelist its keys, and coerce values to strings."""
        try:
            length = int(self.headers.get("Content-Length", 0))
        except ValueError:
            length = -1
        if length < 0 or length > MAX_BODY:
            self.send(413 if length > MAX_BODY else 400, {"error": "Bad or oversized request body"}); return None
        try:
            data = json.loads(self.rfile.read(length) or b"{}")
        except json.JSONDecodeError:
            self.send(400, {"error": "Body must be valid JSON"}); return None
        if not isinstance(data, dict):
            self.send(400, {"error": "Body must be a JSON object"}); return None
        unknown = set(data) - set(allowed)
        if unknown:
            self.send(400, {"error": "Unknown field(s)", "reason": ", ".join(sorted(unknown))}); return None
        missing = [k for k in required if k not in data]
        if missing:
            self.send(400, {"error": "Missing required field(s)", "reason": ", ".join(missing)}); return None
        out = {}
        for k, v in data.items():
            if isinstance(v, (dict, list)) and k != "metadata":
                self.send(400, {"error": f"Field '{k}' must be a string or number"}); return None
            out[k] = json.dumps(v) if isinstance(v, (dict, list)) else str(v)
        return out

    # ---- routing
    def do_GET(self):
        parts = [p for p in self.path.split("?")[0].split("/") if p]
        qs = dict(q.split("=", 1) for q in self.path.partition("?")[2].split("&") if "=" in q)
        if parts == ["health"]:
            return self.send(200, {"status": "ok"})
        if parts == ["samples"]:
            args = ["sample", "list"]
            for k in ("status", "client"):
                if k in qs: args += [f"--{k}", qs[k]]
            return self.cli(args)
        if len(parts) == 2 and parts[0] == "samples":
            if not SAMPLE_ID.match(parts[1]): return self.send(400, {"error": "Invalid sample ID"})
            return self.cli(["sample", "show", parts[1]], transform=lambda d: d[0] if d else {})
        if len(parts) == 3 and parts[0] == "samples" and parts[2] == "results":
            if not SAMPLE_ID.match(parts[1]): return self.send(400, {"error": "Invalid sample ID"})
            return self.cli(["result", "show", parts[1]])
        if parts == ["tests"]:
            return self.cli(["test", "list"])
        if parts == ["clients"]:
            return self.cli(["client", "list"])
        if len(parts) == 3 and parts[0] == "audit":
            if parts[1].lower() not in ENTITIES: return self.send(400, {"error": "Unknown entity"})
            return self.cli(["audit", "show", parts[1], parts[2]])
        self.send(404, {"error": "Not found"})

    def do_POST(self):
        parts = [p for p in self.path.split("?")[0].split("/") if p]
        if parts == ["samples"]:
            b = self.body({"client", "type", "collected", "received", "priority", "description", "metadata"},
                          ("client", "type", "collected"))
            if b is None: return
            args = ["sample", "create"] + [x for k, v in b.items() for x in (f"--{k}", v)]
            code, out, err = run_lab(args, self.headers.get("X-Lab-User"))
            if code != 0: return self.send(HTTP_FOR_EXIT.get(code, 500), parse_error(err, code))
            sid = re.search(r"SAM-[0-9]{4,}", out).group(0)
            return self.cli(["sample", "show", sid], 201, lambda d: d[0])
        if parts == ["tests"]:
            b = self.body({"code", "name", "datatype", "unit", "min", "max", "pmin", "pmax", "allowed", "method", "description"},
                          ("code", "name", "datatype"))
            if b is None: return
            args = ["test", "create", b.pop("code"), b.pop("name")] + [x for k, v in b.items() for x in (f"--{k}", v)]
            code, out, err = run_lab(args, self.headers.get("X-Lab-User"))
            if code != 0: return self.send(HTTP_FOR_EXIT.get(code, 500), parse_error(err, code))
            return self.cli(["test", "show", args[2]], 201, lambda d: d[0])
        if len(parts) == 3 and parts[0] == "samples" and parts[2] in ("results", "requests", "status"):
            sid = parts[1]
            if not SAMPLE_ID.match(sid): return self.send(400, {"error": "Invalid sample ID"})
            user = self.headers.get("X-Lab-User")
            if parts[2] == "results":
                b = self.body({"test", "value", "unit"}, ("test", "value"))
                if b is None: return
                args = ["result", "add", sid, b["test"], b["value"]] + (["--unit", b["unit"]] if "unit" in b else [])
                code, out, err = run_lab(args, user)
                if code != 0: return self.send(HTTP_FOR_EXIT.get(code, 500), parse_error(err, code))
                return self.cli(["result", "show", sid], 201, lambda d: [r for r in d if r["test"] == b["test"]][0])
            if parts[2] == "requests":
                b = self.body({"test"}, ("test",))
                if b is None: return
                code, out, err = run_lab(["request", "create", sid, b["test"]], user)
                if code != 0: return self.send(HTTP_FOR_EXIT.get(code, 500), parse_error(err, code))
                return self.send(201, {"sample": sid, "test": b["test"], "requested": True})
            b = self.body({"status", "reason"}, ("status",))
            if b is None: return
            args = ["sample", "set-status", sid, b["status"]] + (["--reason", b["reason"]] if "reason" in b else [])
            code, out, err = run_lab(args, user)
            if code != 0: return self.send(HTTP_FOR_EXIT.get(code, 500), parse_error(err, code))
            return self.cli(["sample", "show", sid], 200, lambda d: d[0])
        self.send(404, {"error": "Not found"})


def config_value(key, default):
    if key in os.environ: return os.environ[key]
    try:
        for line in open(os.path.join(ROOT, "config", "lims.conf")):
            m = re.match(rf"^\s*{key}=(\S+)", line)
            if m: return m.group(1)
    except OSError:
        pass
    return default


def make_server(host, port):
    return ThreadingHTTPServer((host, port), Api)


if __name__ == "__main__":
    host = config_value("LAB_API_HOST", "127.0.0.1")
    port = int(config_value("LAB_API_PORT", "8080"))
    print(f"mini-LIMS API on http://{host}:{port}  (Ctrl-C to stop)  identity: X-Lab-User header", file=sys.stderr)
    try:
        make_server(host, port).serve_forever()
    except KeyboardInterrupt:
        pass
