-- 003: workflow + business rules as database triggers.
-- Every rule message starts with 'RULE:' so the CLI can turn it into a friendly error (exit code 5).
-- Keep messages free of " (" : the CLI strips sqlite's trailing " (19)" error code by cutting at it.
-- NOTE: RAISE() only accepts a string LITERAL, so messages cannot be built with ||.

-- ---------------------------------------------------------------- workflow (data-driven)
CREATE TABLE workflow_transitions (
    from_status   TEXT NOT NULL,
    to_status     TEXT NOT NULL,
    allowed_roles TEXT NOT NULL,           -- comma-separated roles allowed to perform it
    PRIMARY KEY (from_status, to_status)
);
INSERT INTO workflow_transitions VALUES
    ('RECEIVED',   'REGISTERED', 'ANALYST,ADMIN'),
    ('REGISTERED', 'IN_TESTING', 'ANALYST,ADMIN'),
    ('IN_TESTING', 'COMPLETED',  'ANALYST,ADMIN'),
    ('COMPLETED',  'REVIEWED',   'REVIEWER,ADMIN'),
    ('REVIEWED',   'APPROVED',   'REVIEWER,ADMIN'),
    ('COMPLETED',  'IN_TESTING', 'ANALYST,REVIEWER,ADMIN'),   -- reopen: reviewer finds a problem
    ('REVIEWED',   'IN_TESTING', 'REVIEWER,ADMIN'),           -- reopen after review
    ('RECEIVED',   'CANCELLED',  'ANALYST,ADMIN'),
    ('REGISTERED', 'CANCELLED',  'ANALYST,ADMIN'),
    ('IN_TESTING', 'CANCELLED',  'ADMIN');
-- APPROVED and CANCELLED have no outgoing rows: they are final.

-- ---------------------------------------------------------------- samples
CREATE TRIGGER trg_sample_insert BEFORE INSERT ON samples
BEGIN
    SELECT RAISE(ABORT, 'RULE: new samples must start in status RECEIVED')
        WHERE NEW.status <> 'RECEIVED';
    SELECT RAISE(ABORT, 'RULE: client is inactive and cannot submit samples')
        WHERE (SELECT active FROM clients WHERE id = NEW.client_id) = 0;
END;

CREATE TRIGGER trg_sample_final_locked BEFORE UPDATE ON samples
WHEN OLD.status IN ('APPROVED','CANCELLED')
BEGIN
    SELECT RAISE(ABORT, 'RULE: sample is in a final status and can no longer be changed');
END;

CREATE TRIGGER trg_sample_identity_locked BEFORE UPDATE OF client_id, sample_type, collection_date, reception_date ON samples
WHEN OLD.status NOT IN ('RECEIVED','REGISTERED')
 AND (NEW.client_id IS NOT OLD.client_id OR NEW.sample_type IS NOT OLD.sample_type
   OR NEW.collection_date IS NOT OLD.collection_date OR NEW.reception_date IS NOT OLD.reception_date)
BEGIN
    SELECT RAISE(ABORT, 'RULE: client, type and dates can only change before testing starts');
END;

CREATE TRIGGER trg_sample_code_immutable BEFORE UPDATE OF code ON samples
WHEN NEW.code <> OLD.code
BEGIN SELECT RAISE(ABORT, 'RULE: sample code can never change'); END;

CREATE TRIGGER trg_sample_transition BEFORE UPDATE OF status ON samples
WHEN NEW.status <> OLD.status
BEGIN
    SELECT RAISE(ABORT, 'RULE: this status transition is not allowed by the workflow')
        WHERE NOT EXISTS (SELECT 1 FROM workflow_transitions
                          WHERE from_status = OLD.status AND to_status = NEW.status);
    SELECT RAISE(ABORT, 'RULE: cannot start testing: no tests have been requested')
        WHERE NEW.status = 'IN_TESTING' AND OLD.status = 'REGISTERED'
          AND NOT EXISTS (SELECT 1 FROM test_requests WHERE sample_id = NEW.id);
    SELECT RAISE(ABORT, 'RULE: some requested tests have no result yet')
        WHERE NEW.status IN ('COMPLETED','REVIEWED')
          AND EXISTS (SELECT 1 FROM test_requests tr LEFT JOIN results r ON r.request_id = tr.id
                      WHERE tr.sample_id = NEW.id AND r.id IS NULL);
    SELECT RAISE(ABORT, 'RULE: sample has INVALID results that must be corrected first')
        WHERE NEW.status IN ('COMPLETED','REVIEWED')
          AND EXISTS (SELECT 1 FROM test_requests tr JOIN results r ON r.request_id = tr.id
                      WHERE tr.sample_id = NEW.id AND r.flag = 'INVALID');
END;

-- Keep result status in step with the sample status (review/approval/reopen).
CREATE TRIGGER trg_sample_status_to_results AFTER UPDATE OF status ON samples
WHEN NEW.status IN ('IN_TESTING','REVIEWED','APPROVED') AND NEW.status <> OLD.status
BEGIN
    UPDATE results
       SET status = CASE NEW.status WHEN 'IN_TESTING' THEN 'ENTERED' ELSE NEW.status END
     WHERE request_id IN (SELECT id FROM test_requests WHERE sample_id = NEW.id);
END;

CREATE TRIGGER trg_sample_delete BEFORE DELETE ON samples
WHEN OLD.status <> 'RECEIVED'
BEGIN SELECT RAISE(ABORT, 'RULE: only samples still in RECEIVED can be deleted'); END;

-- ---------------------------------------------------------------- tests
CREATE TRIGGER trg_test_datatype_locked BEFORE UPDATE OF datatype ON tests
WHEN NEW.datatype <> OLD.datatype AND EXISTS (SELECT 1 FROM test_requests WHERE test_id = OLD.id)
BEGIN SELECT RAISE(ABORT, 'RULE: cannot change the datatype of a test that has been requested'); END;

-- ---------------------------------------------------------------- requests
CREATE TRIGGER trg_request_insert BEFORE INSERT ON test_requests
BEGIN
    SELECT RAISE(ABORT, 'RULE: tests can only be requested while the sample is REGISTERED or IN_TESTING')
        WHERE (SELECT status FROM samples WHERE id = NEW.sample_id) NOT IN ('REGISTERED','IN_TESTING');
    SELECT RAISE(ABORT, 'RULE: test is inactive and cannot be requested')
        WHERE (SELECT active FROM tests WHERE id = NEW.test_id) = 0;
END;

-- ---------------------------------------------------------------- results
CREATE TRIGGER trg_result_insert BEFORE INSERT ON results
BEGIN
    SELECT RAISE(ABORT, 'RULE: results can only be entered while the sample is REGISTERED or IN_TESTING')
        WHERE (SELECT s.status FROM test_requests tr JOIN samples s ON s.id = tr.sample_id
               WHERE tr.id = NEW.request_id) NOT IN ('REGISTERED','IN_TESTING');
    SELECT RAISE(ABORT, 'RULE: numeric tests require a numeric value')
        WHERE NEW.value_num IS NULL
          AND (SELECT t.datatype FROM test_requests tr JOIN tests t ON t.id = tr.test_id
               WHERE tr.id = NEW.request_id) = 'NUMERIC';
END;

-- Results are locked once the sample is REVIEWED/APPROVED/CANCELLED. Reopen the sample to correct.
CREATE TRIGGER trg_result_locked BEFORE UPDATE ON results
WHEN (NEW.value_text IS NOT OLD.value_text OR NEW.value_num IS NOT OLD.value_num
   OR NEW.unit IS NOT OLD.unit OR NEW.flag IS NOT OLD.flag OR NEW.request_id IS NOT OLD.request_id)
 AND (SELECT s.status FROM test_requests tr JOIN samples s ON s.id = tr.sample_id
      WHERE tr.id = OLD.request_id) NOT IN ('REGISTERED','IN_TESTING','COMPLETED')
BEGIN
    -- REGISTERED is included on purpose: the flag trigger updates a brand-new result while the
    -- sample is still REGISTERED (the CLI moves it to IN_TESTING right after the insert).
    SELECT RAISE(ABORT, 'RULE: result is locked because the sample is REVIEWED, APPROVED or CANCELLED');
END;

CREATE TRIGGER trg_result_no_delete BEFORE DELETE ON results
BEGIN SELECT RAISE(ABORT, 'RULE: results cannot be deleted, correct them instead'); END;

-- Flag logic lives in ONE view; the triggers below apply it on insert and on value change.
CREATE VIEW v_result_expected_flag AS
SELECT r.id AS result_id,
       CASE t.datatype
         WHEN 'NUMERIC' THEN
           CASE
             WHEN (t.physical_min IS NOT NULL AND r.value_num < t.physical_min)
               OR (t.physical_max IS NOT NULL AND r.value_num > t.physical_max) THEN 'INVALID'
             WHEN t.min_value IS NOT NULL AND r.value_num < t.min_value THEN 'LOW'
             WHEN t.max_value IS NOT NULL AND r.value_num > t.max_value THEN 'HIGH'
             ELSE 'NORMAL'
           END
         WHEN 'ENUM' THEN
           CASE WHEN instr(',' || t.allowed_values || ',', ',' || r.value_text || ',') > 0
                THEN 'NORMAL' ELSE 'INVALID' END
         ELSE 'NORMAL'
       END AS flag
FROM results r
JOIN test_requests tr ON tr.id = r.request_id
JOIN tests t ON t.id = tr.test_id;

CREATE TRIGGER trg_result_flag_ins AFTER INSERT ON results
BEGIN
    UPDATE results SET flag = (SELECT flag FROM v_result_expected_flag WHERE result_id = NEW.id)
     WHERE id = NEW.id;
END;

CREATE TRIGGER trg_result_flag_upd AFTER UPDATE OF value_text, value_num ON results
BEGIN
    UPDATE results SET flag = (SELECT flag FROM v_result_expected_flag WHERE result_id = NEW.id),
                       updated_at = strftime('%Y-%m-%dT%H:%M:%SZ','now')
     WHERE id = NEW.id;
END;

-- Convenience view for the CLI and API: one row per requested test, with its result if any.
CREATE VIEW v_sample_results AS
SELECT s.code AS sample, t.code AS test, t.name AS test_name,
       r.value_text AS value, COALESCE(r.unit, t.unit) AS unit,
       r.flag, COALESCE(r.status, 'PENDING') AS result_status,
       r.analyst, r.entered_at
FROM test_requests tr
JOIN samples s ON s.id = tr.sample_id
JOIN tests   t ON t.id = tr.test_id
LEFT JOIN results r ON r.request_id = tr.id;

-- ---------------------------------------------------------------- users
-- Never lock everybody out: the last active ADMIN cannot be deactivated or demoted.
CREATE TRIGGER trg_user_last_admin BEFORE UPDATE OF active, role ON users
WHEN OLD.role = 'ADMIN' AND OLD.active = 1 AND (NEW.active = 0 OR NEW.role <> 'ADMIN')
 AND NOT EXISTS (SELECT 1 FROM users WHERE role = 'ADMIN' AND active = 1 AND id <> OLD.id)
BEGIN SELECT RAISE(ABORT, 'RULE: cannot deactivate or demote the last active ADMIN'); END;
