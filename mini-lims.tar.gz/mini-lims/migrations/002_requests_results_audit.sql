-- 002: what was asked (requests), what was found (results), and who did what (audit).

CREATE TABLE test_requests (
    id           INTEGER PRIMARY KEY,
    sample_id    INTEGER NOT NULL REFERENCES samples(id),   -- default RESTRICT: no orphaning
    test_id      INTEGER NOT NULL REFERENCES tests(id),
    requested_by TEXT NOT NULL,
    requested_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
    UNIQUE (sample_id, test_id)                               -- a test is requested once per sample
);
CREATE INDEX idx_requests_test ON test_requests(test_id);

-- One result row per request. Corrections UPDATE the row; history lives in the audit log.
CREATE TABLE results (
    id         INTEGER PRIMARY KEY,
    request_id INTEGER NOT NULL UNIQUE REFERENCES test_requests(id),
    value_text TEXT NOT NULL,
    value_num  REAL,                       -- populated for NUMERIC tests
    unit       TEXT,
    flag       TEXT NOT NULL DEFAULT 'NORMAL' CHECK (flag IN ('NORMAL','LOW','HIGH','INVALID')),
    status     TEXT NOT NULL DEFAULT 'ENTERED' CHECK (status IN ('ENTERED','REVIEWED','APPROVED')),
    analyst    TEXT NOT NULL,
    entered_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now'))
);

CREATE TABLE audit_log (
    id          INTEGER PRIMARY KEY,
    ts          TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
    username    TEXT NOT NULL,
    action      TEXT NOT NULL,
    entity      TEXT NOT NULL,            -- SAMPLE, RESULT, TEST, CLIENT, USER, IMPORT, SYSTEM
    entity_id   TEXT NOT NULL,
    sample_code TEXT,                     -- lets 'audit show SAM-0001' gather everything about a sample
    old_value   TEXT,                     -- JSON
    new_value   TEXT,                     -- JSON
    details     TEXT
);
CREATE INDEX idx_audit_sample ON audit_log(sample_code, id);
CREATE INDEX idx_audit_entity ON audit_log(entity, entity_id);

-- An audit log that can be edited is not an audit log.
CREATE TRIGGER trg_audit_no_update BEFORE UPDATE ON audit_log
BEGIN SELECT RAISE(ABORT, 'RULE: audit records are immutable'); END;
CREATE TRIGGER trg_audit_no_delete BEFORE DELETE ON audit_log
BEGIN SELECT RAISE(ABORT, 'RULE: audit records are immutable'); END;

CREATE TABLE import_runs (
    id         INTEGER PRIMARY KEY,
    filename   TEXT NOT NULL,
    username   TEXT NOT NULL,
    started_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
    total_rows INTEGER NOT NULL,
    imported   INTEGER NOT NULL,
    rejected   INTEGER NOT NULL
);
