-- 001: reference data and the sample itself.
-- Design rule: constraints that protect data integrity live HERE, in the database,
-- so they hold even if someone bypasses the CLI (raw sqlite3, another client, a bug).

CREATE TABLE counters (
    name  TEXT PRIMARY KEY,
    value INTEGER NOT NULL DEFAULT 0
);
-- A counter table (instead of MAX(id)+1) guarantees sample codes are never reused after a delete.
INSERT INTO counters(name, value) VALUES ('sample', 0);

CREATE TABLE users (
    id         INTEGER PRIMARY KEY,
    username   TEXT NOT NULL UNIQUE
               CHECK (length(username) BETWEEN 3 AND 32 AND username NOT GLOB '*[^a-z0-9_]*'),
    full_name  TEXT,
    role       TEXT NOT NULL CHECK (role IN ('ADMIN','ANALYST','REVIEWER')),
    active     INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0,1)),
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now'))
);

CREATE TABLE clients (
    id            INTEGER PRIMARY KEY,
    code          TEXT NOT NULL UNIQUE CHECK (length(code) BETWEEN 2 AND 16),
    name          TEXT NOT NULL UNIQUE CHECK (length(trim(name)) > 0),
    contact_name  TEXT,
    contact_email TEXT CHECK (contact_email IS NULL OR contact_email LIKE '%_@_%._%'),
    contact_phone TEXT,
    active        INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0,1)),
    created_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now'))
);

-- Sample types are a table (not a CHECK list) so a lab can add types without a schema change.
CREATE TABLE sample_types (
    code        TEXT PRIMARY KEY,
    description TEXT NOT NULL
);

CREATE TABLE samples (
    id              INTEGER PRIMARY KEY,
    code            TEXT NOT NULL UNIQUE,                      -- e.g. SAM-0001 (human-facing ID)
    client_id       INTEGER NOT NULL REFERENCES clients(id),
    sample_type     TEXT NOT NULL REFERENCES sample_types(code),
    collection_date TEXT NOT NULL CHECK (collection_date GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'),
    reception_date  TEXT NOT NULL CHECK (reception_date  GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'),
    status          TEXT NOT NULL DEFAULT 'RECEIVED'
                    CHECK (status IN ('RECEIVED','REGISTERED','IN_TESTING','COMPLETED','REVIEWED','APPROVED','CANCELLED')),
    priority        TEXT NOT NULL DEFAULT 'ROUTINE' CHECK (priority IN ('ROUTINE','URGENT')),
    description     TEXT,
    metadata        TEXT CHECK (metadata IS NULL OR json_valid(metadata)),
    created_by      TEXT NOT NULL,
    created_at      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
    updated_at      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
    CHECK (reception_date >= collection_date)                  -- ISO dates compare correctly as text
);
CREATE INDEX idx_samples_client ON samples(client_id);
CREATE INDEX idx_samples_status ON samples(status);

-- Test catalogue. The specification (min/max/physical limits/allowed values) is DATA,
-- so flagging is configurable per test instead of hard-coded.
CREATE TABLE tests (
    id             INTEGER PRIMARY KEY,
    code           TEXT NOT NULL UNIQUE,
    name           TEXT NOT NULL,
    description    TEXT,
    unit           TEXT,
    datatype       TEXT NOT NULL CHECK (datatype IN ('NUMERIC','TEXT','ENUM')),
    min_value      REAL,          -- specification lower limit  (below => LOW)
    max_value      REAL,          -- specification upper limit  (above => HIGH)
    physical_min   REAL,          -- physically possible lower bound (below => INVALID)
    physical_max   REAL,          -- physically possible upper bound (above => INVALID)
    allowed_values TEXT,          -- ENUM only: comma-separated list
    method         TEXT,
    active         INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0,1)),
    CHECK (min_value IS NULL OR max_value IS NULL OR min_value <= max_value),
    CHECK (datatype <> 'ENUM' OR allowed_values IS NOT NULL)
);
