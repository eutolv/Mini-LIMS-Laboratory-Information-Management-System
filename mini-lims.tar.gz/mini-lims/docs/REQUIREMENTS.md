# Requisitos e premissas

## Objetivo
Laboratório-escola: código completo, legível e executável localmente para praticar Bash, SQL, APIs e troubleshooting.

## Requisitos funcionais (todos implementados)
RF1 clientes · RF2 amostras (ciclo de vida) · RF3 catálogo de testes com especificação · RF4 solicitações de teste ·
RF5 resultados com flags · RF6 auditoria imutável · RF7 usuários/papéis · RF8 importação CSV · RF9 backup/restore/health/logs ·
RF10 API REST · RF11 testes automatizados.

## Regras de negócio
| # | Regra | Onde é imposta |
|---|---|---|
| R1 | Só transições listadas em `workflow_transitions` | trigger + CLI (mensagem amigável) |
| R2 | Amostra só nasce `RECEIVED`; cliente inativo não envia amostras | trigger |
| R3 | Teste só pode ser solicitado se ativo e amostra `REGISTERED`/`IN_TESTING` | trigger + CLI |
| R4 | Uma solicitação por (amostra, teste) | UNIQUE |
| R5 | Resultado exige solicitação prévia | CLI (+FK) |
| R6 | Valor deve casar com o datatype; unidade deve ser a do teste | CLI (`result_validate`), trigger p/ NUMERIC |
| R7 | Flag: `<min` LOW, `>max` HIGH, fora dos limites físicos ou ENUM inválido → INVALID | view + triggers (configurável por teste) |
| R8 | Primeiro resultado move `REGISTERED → IN_TESTING` (auditado) | CLI |
| R9 | `COMPLETED` exige resultado para todos os testes e nenhum INVALID | trigger |
| R10 | Resultados travam em REVIEWED/APPROVED/CANCELLED; correção exige `--reason` | trigger + CLI |
| R11 | APPROVED e CANCELLED são finais; nada muda | trigger |
| R12 | Resultado nunca é apagado; auditoria nunca é editada/apagada | trigger |
| R13 | Só amostras `RECEIVED` podem ser apagadas; código nunca é reutilizado | trigger + tabela `counters` |
| R14 | Nunca desativar/rebaixar o último ADMIN | trigger |
| R15 | Cliente, tipo e datas só mudam antes do teste começar | trigger |

## Avaliação crítica dos exemplos do enunciado
- "Amostra não recebe testes após aprovação": ampliado — só recebe em `REGISTERED`/`IN_TESTING`.
- "Resultado aprovado não pode ser modificado casualmente": tornado **absoluto**; para corrigir, reabra (`lab sample reopen`, papel REVIEWER/ADMIN) e a mudança fica auditada.
- Flag `INVALID` definida como "impossível fisicamente" (pH > 14) — é armazenada e **bloqueia a conclusão**, em vez de rejeitar, para que o erro fique visível e rastreável.

## Premissas
SQLite basta (usuário único/poucos); identidade sem senha; datas ISO `YYYY-MM-DD` em UTC; a CLI é a única camada de serviço (a API a reutiliza); um resultado por (amostra, teste).
