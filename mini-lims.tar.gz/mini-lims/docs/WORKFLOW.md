# Workflow da amostra

```
RECEIVED ─register→ REGISTERED ─(1º resultado)→ IN_TESTING ─complete→ COMPLETED ─review→ REVIEWED ─approve→ APPROVED
                                                     ▲                    │              │
                                                     └──────── reopen ────┴──────────────┘
RECEIVED / REGISTERED / IN_TESTING(admin) ─cancel→ CANCELLED          (APPROVED e CANCELLED são finais)
```
| De → Para | Papéis |
|---|---|
| RECEIVED→REGISTERED, REGISTERED→IN_TESTING, IN_TESTING→COMPLETED | ANALYST, ADMIN |
| COMPLETED→REVIEWED, REVIEWED→APPROVED | REVIEWER, ADMIN |
| COMPLETED→IN_TESTING (reopen) | ANALYST, REVIEWER, ADMIN |
| REVIEWED→IN_TESTING (reopen) | REVIEWER, ADMIN |
| →CANCELLED | ANALYST, ADMIN (IN_TESTING: só ADMIN) |

Pré-condições (triggers): IN_TESTING exige ≥1 teste solicitado; COMPLETED/REVIEWED exigem todos os resultados e nenhum INVALID.
`lab system workflow` imprime a tabela real do banco. Melhoria futura: segregação de funções (quem revisou não aprova).
