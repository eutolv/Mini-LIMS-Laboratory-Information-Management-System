# Banco de dados (SQLite)

```
clients 1─* samples *─1 sample_types        users (papéis)
samples 1─* test_requests *─1 tests
test_requests 1─0..1 results
audit_log (sem FKs, de propósito: sobrevive à exclusão de amostras)
workflow_transitions · counters · import_runs · schema_migrations
views: v_result_expected_flag (lógica de flag) · v_sample_results
```
- Migrações: `migrations/NNN_nome.sql`, aplicadas em ordem, cada uma em transação, registradas em `schema_migrations`. `lab system migrate`.
- `PRAGMA foreign_keys=ON` é ativado em **toda** conexão (o SQLite o desliga por padrão!).
- Índices: `samples(client_id)`, `samples(status)`, `test_requests(test_id)`, `audit_log(sample_code,id)`, `audit_log(entity,entity_id)`.
- Datas: texto ISO-8601 UTC (ordena corretamente como texto).
- Consultas úteis:
```sql
SELECT status, count(*) FROM samples GROUP BY status;
SELECT sample, test, value, flag FROM v_sample_results WHERE flag IN ('HIGH','LOW','INVALID');
SELECT action, count(*) FROM audit_log GROUP BY action ORDER BY 2 DESC;
```
- Reset: `lab system reset --yes` (guarda cópia em `backups/pre-reset-*`). Backup/restore: docs/OPERATIONS.md.
- Abrir para explorar: `sqlite3 -header -column data/lims.db` (use `PRAGMA foreign_keys=ON;` antes de escrever).
