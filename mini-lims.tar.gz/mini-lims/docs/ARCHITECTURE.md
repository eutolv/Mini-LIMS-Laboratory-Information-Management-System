# Arquitetura

```
 curl ──► server.py ──(argv, sem shell)──►┐
 usuário ─────────────────────────────────►│ bin/lab ─► src/cmd/*.sh ─► src/lib/*.sh ─► sqlite3 ─► lims.db
                                           │   (validação + permissões)       (SQL via stdin)   (constraints + triggers)
```

## Decisões e trade-offs
1. **Bash para a CLI** — a fase é sobre lógica de shell; cada comando é uma função pequena.
2. **Integridade no banco** — regras críticas são triggers/constraints: valem mesmo se alguém usar `sqlite3` direto ou o código Bash tiver bug. A CLI valida antes só para dar erros melhores. *Custo:* mensagens de trigger são literais (RAISE não concatena).
3. **API chama a CLI** (`subprocess`, lista de argumentos) — zero regra duplicada; CLI e API nunca divergem. *Custo:* um processo por requisição; nada de estado em memória.
4. **Transação única por operação** — mudança + linha de auditoria no mesmo `BEGIN IMMEDIATE ... COMMIT`; se falha, nada fica. Estado "antes" é capturado em tabela TEMP (`snap_begin`).
5. **SQL montado com `sql_quote`** (aspas duplicadas) + validação estrita por regex. sqlite3 CLI não tem parâmetros ligados fáceis; em Python/API isso viraria `?` placeholders. Todo SQL entra por stdin (não aparece em `ps`).
6. **Config não é `source`ada** — parser KEY=VALUE com whitelist (arquivo gravável não vira execução de código).
7. **Workflow orientado a dados** — tabela `workflow_transitions` (com papéis); mudar o fluxo = mudar linhas, não código.
8. **Python só na API** — stdlib `http.server`; segunda linguagem justificada porque Bash não serve HTTP de forma sensata.

## Códigos de saída
0 ok · 1 (health: avisos) · 2 uso · 3 validação (também: import terminou com linhas rejeitadas) · 4 não encontrado ·
5 regra/conflito · 6 permissão · 7 banco · 8 configuração/sistema.

## Segurança (revisão resumida)
| Risco | Tratamento |
|---|---|
| Injeção de SQL | `sql_quote` + regex; teste com payload `'); DROP TABLE` |
| Injeção de argumento (`--user admin` como *valor*) | flags globais só antes do recurso; teste dedicado |
| Injeção de shell | sem `eval`; API usa lista argv; despacho por allow-list `^[a-z]+$` |
| Path traversal | restore só de dentro de `backups/` (readlink -f); noun validado antes de virar caminho |
| Execução via config | parser com whitelist, sem `source` |
| Arquivos temporários | `mktemp` (0600) + `umask 077`; backups 600, diretórios 700 |
| Logs sensíveis | só nomes de comando e códigos; sem valores de argumentos; sem caracteres de controle |
| Escalada de privilégio | nada usa sudo/setuid; papéis checados na CLI e transições no banco |
| **Autenticação** | **inexistente**: `LAB_USER`/`X-Lab-User` são declarações, não provas. Qualquer um com acesso ao shell/porta pode se passar por admin. Só para aprendizado; bind da API em 127.0.0.1. |
