# API REST

`python3 src/api/server.py` (padrão `127.0.0.1:8080`, configurável em `config/lims.conf`). JSON. Identidade: cabeçalho `X-Lab-User` (padrão: `LAB_DEFAULT_USER`). **Sem autenticação real.**

| Método | Rota | Corpo |
|---|---|---|
| GET | `/samples?status=&client=` · `/samples/{id}` · `/samples/{id}/results` | |
| POST | `/samples` | `{"client","type","collected"[,"received","priority","description","metadata"]}` → 201 |
| POST | `/samples/{id}/requests` | `{"test":"PH"}` → 201 |
| POST | `/samples/{id}/results` | `{"test","value"[,"unit"]}` → 201 |
| POST | `/samples/{id}/status` | `{"status":"REGISTERED"[,"reason"]}` |
| GET / POST | `/tests` | POST: `{"code","name","datatype"[,"unit","min","max",...]}` |
| GET | `/clients` · `/audit/{entity}/{id}` (ex.: `/audit/sample/SAM-0001`) | |

Erros: `{"error","reason","exit_code"}`. Mapeamento: 400 uso · 422 validação · 404 não encontrado · 409 regra/conflito · 403 permissão · 503 banco.
```bash
curl -s -X POST localhost:8080/samples -H 'X-Lab-User: analyst1' \
  -d '{"client":"ACME","type":"WATER","collected":"2026-09-25"}'
curl -s -X POST localhost:8080/samples/SAM-0001/status -d '{"status":"REGISTERED"}'
curl -s -X POST localhost:8080/samples/SAM-0001/requests -d '{"test":"PH"}'
curl -s -X POST localhost:8080/samples/SAM-0001/results -d '{"test":"PH","value":"9.2"}'
# → {"test":"PH","value":"9.2","unit":"pH","flag":"HIGH","status":"ENTERED",...}
curl -s -X POST localhost:8080/samples -H 'X-Lab-User: reviewer1' -d '{"client":"ACME","type":"WATER","collected":"2026-09-25"}'
# → 403 {"error":"Permission denied.","reason":"Role REVIEWER may not perform 'sample.create'...","exit_code":6}
```
Limites: corpo ≤ 64 KB, campos fora da lista são recusados (400). Sem TLS/limite de taxa: não exponha a rede.
