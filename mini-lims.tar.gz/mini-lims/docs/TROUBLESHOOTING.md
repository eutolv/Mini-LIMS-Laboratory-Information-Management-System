# Solução de problemas
| Sintoma | Causa provável / ação |
|---|---|
| `sqlite3 is not installed` (8) | `sudo apt install sqlite3` |
| `Database not found` (7) | `lab system init --seed` ou verifique `LAB_DB` |
| `Unknown user 'x'` (6) | `LAB_USER` errado; `LAB_USER=admin lab user list` |
| `Database is busy` (7) | outro processo escreve; tente de novo; veja `lsof data/lims.db` |
| `Business rule violated` (5) | leia o "Reason"; `lab sample status ID` mostra próximos passos |
| Erro estranho de `-box`/`-json` | sqlite3 < 3.33: atualize (`sqlite3 --version`) |
| `permission denied` em `bin/lab` | `chmod +x bin/lab scripts/*.sh` |
| Cron não roda | `crontab -l`; `logs/cron.log`; caminhos absolutos; serviço `cron` ativo |
| Port already in use (API) | mude `LAB_API_PORT` |
| Suspeita de corrupção | `lab system health`; `lab system restore <backup> --yes` |
Depuração: `bash -x bin/lab sample list`, `lab system logs --level ERROR`, e reproduza o SQL direto no `sqlite3`.
