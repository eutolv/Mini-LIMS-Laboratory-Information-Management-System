# Testes

`tests/run.sh` — cada suíte usa um banco temporário próprio (nunca toca `data/`).

| Suíte | Cobre |
|---|---|
| `test_cli_validation.sh` | uso/exit codes, IDs inválidos, datas, JSON, injeção SQL e de argumento, usuário desconhecido |
| `test_business_rules.sh` | workflow, flags LOW/HIGH/INVALID/ENUM, permissões, travas pós-revisão/aprovação, **bypass via sqlite3 direto**, auditoria, atomicidade, códigos não reutilizados |
| `test_import.sh` | dry-run, arquivo válido, misto (parcial → exit 3), cabeçalho, vazio, aspas, colunas, duplicatas, permissão |
| `test_operations.sh` | health, backup+checksum, restore, path traversal, backup adulterado, logs, banco ausente |
| `test_api.py` | fluxo completo, mapeamento HTTP, corpos inválidos, injeção, papéis |

Resultado esperado: `ALL TESTS PASSED`. Rodar uma suíte: `bash tests/test_import.sh`. Para depurar, rode o comando à mão com `LAB_DB=/tmp/x.db`.
Não coberto: concorrência real (dois escritores), transação interrompida por `kill -9` (SQLite garante via journal; não testado aqui), carga.
