# Operações

## Health
`lab system health` — sqlite3/versão, config, diretórios graváveis, espaço em disco, permissões do banco, `integrity_check`, `foreign_key_check`, versão do schema, idade e integridade do último backup.
Saída: **0** saudável · **1** só avisos · **7** falha de banco · **8** falha de sistema/config.

## Backup
`lab system backup` (ADMIN) usa `.backup` online do SQLite (cópia consistente com o banco em uso), **verifica** `integrity_check` antes de publicar, grava `lims-AAAAMMDDTHHMMSSZ.db` (modo 600) + `.sha256`, audita e apaga backups mais antigos que `LAB_BACKUP_RETENTION_DAYS`.
Estratégia sugerida: diário (cron) + antes de migrações/restores + copiar `backups/` para *outra* máquina/disco (backup no mesmo disco não protege de falha do disco).

## Restore
```bash
ls backups/
lab system restore lims-20260929T021500Z.db --yes
```
Só aceita arquivos dentro de `backups/`; confere checksum, integridade e se é um banco mini-LIMS; guarda `pre-restore-*.db` (dá para desfazer); substitui o banco atomicamente (`mv`); registra `SYSTEM_RESTORE` na auditoria. Pare a API antes.

## Cron
```bash
scripts/install-cron.sh             # mostra a linha
scripts/install-cron.sh --install   # instala (idempotente)   |  --remove
crontab -l
```
Roda 02:15 diariamente via `scripts/cron-backup.sh` (caminho absoluto, `flock` contra sobreposição, PATH mínimo). Verifique: `lab system logs --level ERROR` e `logs/cron.log`. Os diretórios são criados por `lab system init`.

## Logs
`logs/lims.log`: `timestamp NÍVEL user=... cmd="sample create" mensagem`. Níveis INFO/WARNING/ERROR. `lab system logs --lines 50 --level WARNING`. Não registra valores de argumentos. Rotação (logrotate) fica como melhoria.

## Variáveis
`LAB_DB`, `LAB_LOG_FILE`, `LAB_BACKUP_DIR`, `LAB_USER`, `LAB_CONFIG` (arquivo alternativo). O ambiente vence `config/lims.conf`; `config/local.conf` (ignorado pelo Git) vence ambos os arquivos.
