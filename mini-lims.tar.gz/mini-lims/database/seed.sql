-- Demo data. Applied by 'lab system init --seed'. Uses INSERT OR IGNORE so it is re-runnable.
INSERT OR IGNORE INTO users(username, full_name, role) VALUES
    ('admin',     'System Administrator', 'ADMIN'),
    ('analyst1',  'Ana Analyst',          'ANALYST'),
    ('reviewer1', 'Rui Reviewer',         'REVIEWER');

INSERT OR IGNORE INTO clients(code, name, contact_name, contact_email, contact_phone) VALUES
    ('ACME',  'Acme Water Laboratory',      'Alice Acme',  'alice@acme-water.example',  '+1-555-0101'),
    ('NVE',   'North Valley Environmental', 'Nora Valley', 'nora@nve.example',          '+1-555-0102'),
    ('MWS',   'Municipal Water Services',   'Marco Muni',  'marco@mws.example',         '+1-555-0103');

INSERT OR IGNORE INTO sample_types(code, description) VALUES
    ('WATER',      'Drinking or surface water'),
    ('SOIL',       'Soil or sediment'),
    ('WASTEWATER', 'Influent or effluent wastewater');

-- Reference ranges follow common drinking-water guidance (illustrative, not regulatory advice).
INSERT OR IGNORE INTO tests(code, name, description, unit, datatype, min_value, max_value, physical_min, physical_max, method) VALUES
    ('PH',           'pH',                  'Acidity/alkalinity',              'pH',    'NUMERIC', 6.5,  8.5,  0,   14,    'SM 4500-H+ B'),
    ('TURBIDITY',    'Turbidity',           'Cloudiness of the water',         'NTU',   'NUMERIC', 0,    1.0,  0,   NULL,  'SM 2130 B'),
    ('CHLORINE',     'Free chlorine',       'Residual free chlorine',          'mg/L',  'NUMERIC', 0.2,  4.0,  0,   NULL,  'SM 4500-Cl G'),
    ('CONDUCTIVITY', 'Conductivity',        'Electrical conductivity at 25 C', 'uS/cm', 'NUMERIC', 50,   1500, 0,   NULL,  'SM 2510 B');
INSERT OR IGNORE INTO tests(code, name, description, unit, datatype, allowed_values, method) VALUES
    ('ODOR',         'Odor',                'Qualitative odor assessment',     NULL,    'ENUM',    'NONE,MILD,STRONG', 'SM 2150 B');
