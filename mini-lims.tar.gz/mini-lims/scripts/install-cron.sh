#!/usr/bin/env bash
# install-cron.sh - show (default) or install a daily 02:15 backup cron entry for THIS checkout.
#   scripts/install-cron.sh            # just prints the line; changes nothing
#   scripts/install-cron.sh --install  # adds it to your crontab (idempotent)
#   scripts/install-cron.sh --remove   # removes it
set -Eeuo pipefail
LAB_HOME="$(cd "$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")/.." && pwd)"
TAG="# mini-lims-backup"
LINE="15 2 * * * \"$LAB_HOME/scripts/cron-backup.sh\" >>\"$LAB_HOME/logs/cron.log\" 2>&1 $TAG"

case "${1:-}" in
    "")        echo "Add this line with 'crontab -e' (or run: $0 --install):"; echo "$LINE" ;;
    --install) command -v crontab >/dev/null || { echo "crontab not found (install 'cron')"; exit 8; }
               mkdir -p "$LAB_HOME/logs"
               { crontab -l 2>/dev/null | grep -vF "$TAG" || true; echo "$LINE"; } | crontab -
               echo "Installed. Check with: crontab -l" ;;
    --remove)  { crontab -l 2>/dev/null | grep -vF "$TAG" || true; } | crontab - ; echo "Removed." ;;
    *)         echo "Usage: $0 [--install|--remove]" >&2; exit 2 ;;
esac
