#!/usr/bin/env bash
# demo.sh - narrated walk through the whole lifecycle on a fresh SCRATCH database.
# Your real data is never touched: it uses a temp directory.   Usage: scripts/demo.sh
set -Eeuo pipefail
ROOT="$(cd "$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")/.." && pwd)"
D=$(mktemp -d); trap 'rm -rf "$D"' EXIT
export LAB_DB="$D/lims.db" LAB_LOG_FILE="$D/lims.log" LAB_BACKUP_DIR="$D/backups" LAB_CONFIG=/dev/null
lab() { echo; echo "\$ lab $*"; "$ROOT/bin/lab" "$@" || echo "(exit code $?)"; }
as()  { local u=$1; shift; echo; echo "\$ LAB_USER=$u lab $*"; LAB_USER=$u "$ROOT/bin/lab" "$@" || echo "(exit code $?)"; }

"$ROOT/bin/lab" system init --seed >/dev/null
echo "=== 1. Reference data ===";  lab client list; lab test list
echo; echo "=== 2. Receive and register a sample ==="
lab sample create --client ACME --type WATER --collected "$(date -u +%F)" --description "Tap water, kitchen"
lab sample show SAM-0001
lab sample register SAM-0001
echo; echo "=== 3. Request tests, enter results (note the flag) ==="
lab request create SAM-0001 PH; lab request create SAM-0001 TURBIDITY
lab result add SAM-0001 PH 7.42
lab result add SAM-0001 TURBIDITY 2.5
lab sample status SAM-0001
echo; echo "=== 4. The rules push back ==="
lab request create SAM-0001 ODOR
lab sample complete SAM-0001 || true          # ODOR has no result yet -> refused
lab result add SAM-0001 PH abc || true         # wrong datatype -> refused
lab result add SAM-0001 ODOR MILD
lab result update SAM-0001 TURBIDITY 0.4 --reason "instrument recalibrated, re-read"
echo; echo "=== 5. Complete -> review -> approve, with roles ==="
lab sample complete SAM-0001
as analyst1 sample review SAM-0001            # analysts may not review
as reviewer1 sample review SAM-0001
as reviewer1 sample approve SAM-0001
as analyst1 result update SAM-0001 PH 7.0 --reason "too late"   # approved = locked
echo; echo "=== 6. Everything that happened ==="
lab audit show SAM-0001
