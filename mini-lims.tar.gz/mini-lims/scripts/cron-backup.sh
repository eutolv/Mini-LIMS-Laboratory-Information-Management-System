#!/usr/bin/env bash
# cron-backup.sh - unattended daily backup. Safe to run from cron:
#  * uses an absolute path to the project (cron has a nearly empty environment)
#  * flock prevents two backups overlapping if one runs long
#  * output goes to the application log so failures are visible with: lab system logs --level ERROR
set -Eeuo pipefail
LAB_HOME="$(cd "$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")/.." && pwd)"
export PATH="/usr/local/bin:/usr/bin:/bin"
export LAB_USER="${LAB_USER:-admin}"
LOCK="${TMPDIR:-/tmp}/mini-lims-backup.$(id -u).lock"

exec 9>"$LOCK"
flock -n 9 || { echo "another backup is running; skipping" >&2; exit 0; }
"$LAB_HOME/bin/lab" system backup
