#!/usr/bin/env bash
source "$(dirname "$0")/lib.sh"; setup_env
echo "Operations: health, backup, restore, logs"
lab system health; [[ $RC == 1 ]] && expect_out "no backups found" "health warns when no backup exists" || bad "health (expected rc=1 warning)"
expect_rc 0 "backup succeeds" system backup
B=$(ls "$LAB_BACKUP_DIR"/lims-*.db | head -1)
[[ -f $B && -f $B.sha256 ]] && ok "backup file + checksum exist" || bad "backup files"
expect_eq "$(stat -c %a "$B")" 600 "backup is owner-only (600)"
expect_rc 0 "health is clean after backup" system health
expect_rc 6 "analyst cannot back up" --user analyst1 system backup

lab sample create --client ACME --type WATER --collected 2026-09-20 >/dev/null
expect_eq "$(sql "SELECT count(*) FROM samples;")" 1 "sample exists before restore"
expect_rc 2 "restore needs --yes" system restore "$(basename "$B")"
expect_rc 0 "restore from backup dir" system restore "$(basename "$B")" --yes
expect_eq "$(sql "SELECT count(*) FROM samples;")" 0 "restore rolled data back to the backup state"
expect_eq "$(sql "SELECT count(*) FROM audit_log WHERE action='SYSTEM_RESTORE';")" 1 "restore is audited"
ls "$LAB_BACKUP_DIR"/pre-restore-*.db >/dev/null 2>&1 && ok "safety copy of previous DB kept" || bad "pre-restore copy"

cp /etc/hostname "$T/evil.db" 2>/dev/null || echo x >"$T/evil.db"
expect_rc 3 "restore outside backup dir refused" system restore "$T/evil.db" --yes
expect_rc 3 "path traversal refused" system restore "$LAB_BACKUP_DIR/../evil.db" --yes
expect_rc 4 "missing backup" system restore nothere.db --yes
cp "$B" "$LAB_BACKUP_DIR/lims-tampered.db"; printf 'garbage' >>"$LAB_BACKUP_DIR/lims-tampered.db"
(cd "$LAB_BACKUP_DIR" && sha256sum "lims-$(basename "$B" | cut -d- -f2)" >/dev/null 2>&1) || true
cp "$B.sha256" "$LAB_BACKUP_DIR/lims-tampered.db.sha256"; sed -i 's/lims-[0-9TZ]*\.db/lims-tampered.db/' "$LAB_BACKUP_DIR/lims-tampered.db.sha256"
expect_rc 7 "tampered backup fails checksum" system restore lims-tampered.db --yes

expect_rc 0 "logs readable" system logs --lines 5
expect_rc 3 "logs rejects bad --lines" system logs --lines abc
lab sample show SAM-9999 >/dev/null
lab system logs --level WARNING; expect_out "SAM-9999" "failures are logged as WARNING"
expect_eq "$(grep -c 'DROP\|password' "$LAB_LOG_FILE" || true)" 0 "no sensitive data in logs"
rm -f "$LAB_DB"; expect_rc 7 "health FAILs (rc 7) when the database is missing" system health
expect_rc 7 "commands fail cleanly without a database" sample list
finish
