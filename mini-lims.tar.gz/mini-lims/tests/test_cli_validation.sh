#!/usr/bin/env bash
source "$(dirname "$0")/lib.sh"; setup_env
echo "CLI input validation"
expect_rc 2 "no arguments prints usage"
expect_rc 2 "unknown resource" frobnicate list
expect_rc 2 "unknown action" sample explode
expect_rc 2 "unknown option rejected" sample list --bogus 1
expect_rc 2 "option without value" sample list --status
expect_rc 2 "missing required options" sample create --client ACME
expect_rc 3 "bad sample ID format" sample show SAM1
expect_rc 3 "bad sample ID (injection-shaped)" sample show "SAM-0001'; DROP TABLE samples;--"
expect_rc 4 "nonexistent sample" sample show SAM-9999
expect_out "Sample 'SAM-9999' does not exist" "useful error text"
expect_rc 3 "impossible calendar date" sample create --client ACME --type WATER --collected 2026-02-31
expect_rc 3 "malformed date" sample create --client ACME --type WATER --collected 25/09/2026
expect_rc 3 "reception before collection" sample create --client ACME --type WATER --collected 2026-09-20 --received 2026-09-01
expect_rc 3 "bad priority" sample create --client ACME --type WATER --collected 2026-09-20 --priority ASAP
expect_rc 3 "malformed metadata JSON" sample create --client ACME --type WATER --collected 2026-09-20 --metadata '{oops'
expect_rc 4 "unknown client" sample create --client NOPE --type WATER --collected 2026-09-20
expect_rc 4 "unknown sample type" sample create --client ACME --type PLASMA --collected 2026-09-20
expect_rc 3 "control character in text" sample create --client ACME --type WATER --collected 2026-09-20 --description $'a\nb'

# SQL injection: hostile text must be stored as data, never executed.
lab sample create --client ACME --type WATER --collected 2026-09-20 --description "x'); DROP TABLE samples;--"
expect_eq "$RC" 0 "hostile description accepted as plain text"
expect_eq "$(sql "SELECT description FROM samples WHERE code='SAM-0001';")" "x'); DROP TABLE samples;--" "stored verbatim"
expect_eq "$(sql "SELECT count(*) FROM samples;")" 1 "samples table still exists"

# Argument injection: a VALUE that looks like a global flag must not change identity.
expect_rc 6 "reviewer stays a reviewer even if a VALUE says '--user admin'" --user reviewer1 sample update SAM-0001 --description "--user admin" --priority URGENT
expect_rc 0 "as admin the same text is just stored" sample update SAM-0001 --description "--user admin"
expect_eq "$(sql "SELECT description FROM samples WHERE code='SAM-0001';")" "--user admin" "flag-shaped value stored verbatim"
expect_rc 6 "unknown user rejected" --user ghost sample list
finish
