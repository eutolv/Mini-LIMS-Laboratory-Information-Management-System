#!/usr/bin/env bash
# Tiny test harness. Each suite sources this, calls setup_env, then uses the assert_* helpers.
# Every suite runs against a THROWAWAY database in a temp dir; your real data is never touched.

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
LAB="$ROOT/bin/lab"
PASS=0; FAIL=0
export LAB_CONFIG=/dev/null

setup_env() {
    T=$(mktemp -d "${TMPDIR:-/tmp}/lims-test.XXXXXX")
    export LAB_DB="$T/data/lims.db" LAB_LOG_FILE="$T/logs/lims.log" LAB_BACKUP_DIR="$T/backups"
    unset LAB_USER
    "$LAB" system init --seed >/dev/null || { echo "setup failed"; exit 1; }
    trap 'rm -rf "$T"' EXIT
}

# run CMD... : execute, capture stdout+stderr in $OUT and exit code in $RC
run() { OUT=$("$@" 2>&1) && RC=0 || RC=$?; }
lab() { run "$LAB" "$@"; }

ok()   { PASS=$((PASS + 1)); printf '  ok   %s\n' "$1"; }
bad()  { FAIL=$((FAIL + 1)); printf '  FAIL %s\n       got rc=%s out: %s\n' "$1" "$RC" "${OUT:0:300}"; }

# expect_rc N "description" args...   (runs lab with args)
expect_rc() { local want=$1 desc=$2; shift 2; lab "$@"; [[ $RC == "$want" ]] && ok "$desc" || bad "$desc (wanted rc=$want)"; }
expect_out() { local pat=$1 desc=$2; [[ $OUT == *"$pat"* ]] && ok "$desc" || bad "$desc (missing '$pat')"; }
expect_eq() { [[ $1 == "$2" ]] && ok "$3" || { RC=-; OUT="expected '$2' got '$1'"; bad "$3"; }; }
sql() { sqlite3 -cmd 'PRAGMA foreign_keys=ON;' "$LAB_DB" "$1" 2>&1; }

as() { local u=$1; shift; LAB_USER=$u lab "$@"; }
finish() { echo "  -> $PASS passed, $FAIL failed"; ((FAIL == 0)); }

# helper: a registered sample with PH requested
new_sample() { lab sample create --client ACME --type WATER --collected 2026-09-20 >/dev/null; lab sample register "$1" >/dev/null; }
