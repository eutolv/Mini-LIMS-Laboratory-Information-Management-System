#!/usr/bin/env bash
source "$(dirname "$0")/lib.sh"; setup_env
echo "Business rules, workflow, flags, permissions, audit"
lab sample create --client ACME --type WATER --collected 2026-09-20 >/dev/null   # SAM-0001, RECEIVED

# ---- workflow
expect_rc 5 "cannot skip RECEIVED -> COMPLETED" sample complete SAM-0001
expect_rc 5 "cannot request tests while RECEIVED" request create SAM-0001 PH
lab sample register SAM-0001 >/dev/null
expect_rc 5 "cannot start testing without requests" sample set-status SAM-0001 IN_TESTING
expect_rc 4 "request on nonexistent sample" request create SAM-9999 PH
expect_rc 4 "request for nonexistent test" request create SAM-0001 NOPE
expect_rc 0 "request PH" request create SAM-0001 PH
expect_rc 5 "duplicate request rejected" request create SAM-0001 PH
expect_rc 5 "result for un-requested test rejected" result add SAM-0001 TURBIDITY 0.3
expect_rc 4 "result for nonexistent sample" result add SAM-9999 PH 7
expect_rc 3 "non-numeric value for numeric test" result add SAM-0001 PH seven
expect_rc 3 "unit mismatch" result add SAM-0001 PH 7 --unit mg/L
expect_rc 5 "cannot complete before results exist" sample complete SAM-0001

# ---- flags (configurable per test)
# regression: an out-of-range FIRST result (sample still REGISTERED) must be accepted and flagged
lab request create SAM-0001 ODOR >/dev/null; lab result add SAM-0001 ODOR STRONG >/dev/null; expect_eq "$(sql "SELECT flag FROM v_sample_results WHERE test='ODOR';")" NORMAL "ENUM value in allowed list -> NORMAL"
lab result update SAM-0001 ODOR BITTER --reason "check" >/dev/null; expect_eq "$(sql "SELECT flag FROM v_sample_results WHERE test='ODOR';")" INVALID "ENUM value not allowed -> INVALID"
lab result update SAM-0001 ODOR NONE --reason "fixed" >/dev/null
lab result add SAM-0001 PH 7.42 >/dev/null; expect_eq "$(sql "SELECT flag FROM v_sample_results WHERE sample='SAM-0001' AND test='PH';")" NORMAL "7.42 -> NORMAL"
expect_eq "$(sql "SELECT status FROM samples WHERE code='SAM-0001';")" IN_TESTING "first result moves sample to IN_TESTING"
lab request create SAM-0001 TURBIDITY >/dev/null; lab result add SAM-0001 TURBIDITY 2.5 >/dev/null
expect_eq "$(sql "SELECT flag FROM v_sample_results WHERE test='TURBIDITY';")" HIGH "2.5 NTU -> HIGH"
lab result update SAM-0001 TURBIDITY 0.4 --reason "re-read" >/dev/null
expect_eq "$(sql "SELECT flag FROM v_sample_results WHERE test='TURBIDITY';")" NORMAL "update recomputes flag"
expect_rc 3 "update requires a reason" result update SAM-0001 TURBIDITY 0.5
lab request create SAM-0001 CHLORINE >/dev/null; lab result add SAM-0001 CHLORINE 0.05 >/dev/null
expect_eq "$(sql "SELECT flag FROM v_sample_results WHERE test='CHLORINE';")" LOW "0.05 mg/L -> LOW"
lab request create SAM-0001 CONDUCTIVITY >/dev/null; lab result add SAM-0001 CONDUCTIVITY -5 >/dev/null
expect_eq "$(sql "SELECT flag FROM v_sample_results WHERE test='CONDUCTIVITY';")" INVALID "negative conductivity -> INVALID (physical limit)"
expect_rc 5 "INVALID result blocks completion" sample complete SAM-0001
lab result update SAM-0001 CONDUCTIVITY 400 --reason "typo" >/dev/null
lab result update SAM-0001 CHLORINE 0.5 --reason "re-read" >/dev/null
expect_rc 0 "complete once all results valid" sample complete SAM-0001
expect_rc 5 "cannot add tests after completion" request create SAM-0001 ODOR

# ---- permissions along the workflow
expect_rc 6 "analyst cannot review" --user analyst1 sample review SAM-0001
expect_rc 6 "reviewer cannot create samples" --user reviewer1 sample create --client ACME --type WATER --collected 2026-09-20
expect_rc 5 "cannot approve straight from COMPLETED" --user reviewer1 sample approve SAM-0001
expect_rc 0 "reviewer reviews" --user reviewer1 sample review SAM-0001
expect_rc 6 "analyst cannot approve" --user analyst1 sample approve SAM-0001
expect_rc 5 "results locked after review" result update SAM-0001 PH 7.0 --reason "x"
expect_rc 0 "reviewer approves" --user reviewer1 sample approve SAM-0001
expect_rc 5 "approved sample cannot be edited" sample update SAM-0001 --priority URGENT
expect_rc 5 "approved sample cannot be cancelled" sample cancel SAM-0001
expect_rc 5 "approved results cannot be modified" result update SAM-0001 PH 7.0 --reason "x"
expect_rc 5 "approved sample cannot be deleted" sample delete SAM-0001
expect_eq "$(sql "SELECT DISTINCT status FROM results;")" APPROVED "results carry APPROVED status"

# ---- the DATABASE protects itself when the CLI is bypassed
[[ $(sql "UPDATE samples SET status='RECEIVED' WHERE code='SAM-0001';") == *RULE* ]] && ok "raw SQL cannot un-approve a sample" || bad "raw un-approve"
[[ $(sql "UPDATE samples SET description='x' WHERE code='SAM-0001';") == *final* ]] && ok "raw SQL cannot edit an approved sample" || bad "raw edit"
[[ $(sql "UPDATE results SET value_text='9';") == *RULE* ]] && ok "raw SQL cannot edit approved result" || bad "raw SQL edit result"
[[ $(sql "DELETE FROM audit_log;") == *immutable* ]] && ok "audit log cannot be deleted" || bad "audit delete"
[[ $(sql "UPDATE audit_log SET username='x';") == *immutable* ]] && ok "audit log cannot be edited" || bad "audit edit"
[[ $(sql "INSERT INTO samples(code,client_id,sample_type,collection_date,reception_date,created_by) VALUES ('X',99,'WATER','2026-01-01','2026-01-01','u');") == *FOREIGN* ]] && ok "foreign key enforced" || bad "fk"

# ---- inactive test / client, duplicates, delete rules
lab test update ODOR --active 0 >/dev/null
lab sample create --client ACME --type WATER --collected 2026-09-21 >/dev/null; lab sample register SAM-0002 >/dev/null
expect_rc 5 "inactive test cannot be requested" request create SAM-0002 ODOR
expect_rc 5 "duplicate client code" client create ACME "Other Name"
expect_rc 5 "REGISTERED sample cannot be deleted" sample delete SAM-0002
lab sample create --client ACME --type WATER --collected 2026-09-21 >/dev/null      # SAM-0003, RECEIVED
expect_rc 0 "delete RECEIVED sample" sample delete SAM-0003
lab sample create --client ACME --type WATER --collected 2026-09-21 >/dev/null
expect_eq "$(sql "SELECT max(code) FROM samples;")" SAM-0004 "sample codes are never reused after delete"
lab client update MWS --active 0 >/dev/null
expect_rc 5 "inactive client cannot submit samples" sample create --client MWS --type WATER --collected 2026-09-21
expect_rc 5 "cannot demote the last admin" user update admin --role ANALYST

# ---- audit trail
lab audit show SAM-0001; expect_out "RESULT_CREATED" "audit has RESULT_CREATED"
expect_out "RESULT_UPDATED" "audit has RESULT_UPDATED"; expect_out "SAMPLE_APPROVED" "audit has SAMPLE_APPROVED"
expect_out "TEST_REQUESTED" "audit has TEST_REQUESTED"; expect_out "re-read" "audit keeps the change reason"
lab audit show SAM-0003; expect_out "SAMPLE_DELETED" "deleted sample keeps its history"
expect_rc 4 "audit for unknown sample" audit show SAM-4242
expect_eq "$(sql "SELECT count(*) FROM audit_log WHERE action='SAMPLE_UPDATED';")" 0 "rejected updates wrote no audit rows"

# ---- atomicity: failing statement rolls back the whole transaction, audit row included
before=$(sql "SELECT count(*) FROM audit_log;")
sql "BEGIN; INSERT INTO audit_log(username,action,entity,entity_id) VALUES('t','X','X','1'); INSERT INTO clients(code,name) VALUES ('ACME','dup'); COMMIT;" >/dev/null
expect_eq "$(sql "SELECT count(*) FROM audit_log;")" "$before" "failed transaction leaves no partial audit row"
# regression: out-of-range FIRST result while the sample is still REGISTERED
lab sample create --client NVE --type SOIL --collected 2026-09-22 >/dev/null; n=$(sql "SELECT max(code) FROM samples;")
lab sample register "$n" >/dev/null; lab request create "$n" PH >/dev/null
expect_rc 0 "out-of-range first result accepted on REGISTERED sample" result add "$n" PH 9.9
expect_eq "$(sql "SELECT flag FROM v_sample_results WHERE sample='$n';")" HIGH "...and flagged HIGH"
expect_eq "$(sql "SELECT status FROM samples WHERE code='$n';")" IN_TESTING "...and the sample moved to IN_TESTING"
finish
