#!/usr/bin/env bash
# Run every test suite. Exit code 0 only if ALL pass.  Usage: tests/run.sh
cd "$(dirname "$0")" || exit 1
rc=0
for t in test_cli_validation.sh test_business_rules.sh test_import.sh test_operations.sh; do
    echo "== $t"; bash "$t" || rc=1
done
echo "== test_api.py"; python3 test_api.py 2>&1 | tail -4 || rc=1
[[ ${PIPESTATUS[0]} == 0 ]] || rc=1
((rc == 0)) && echo "ALL TESTS PASSED" || echo "SOME TESTS FAILED"
exit $rc
