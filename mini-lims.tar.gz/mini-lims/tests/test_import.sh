#!/usr/bin/env bash
source "$(dirname "$0")/lib.sh"; setup_env
echo "CSV import"
lab sample create --client ACME --type WATER --collected 2026-09-20 >/dev/null; lab sample register SAM-0001 >/dev/null
lab sample create --client NVE  --type SOIL  --collected 2026-09-20 >/dev/null   # SAM-0002 stays RECEIVED
lab request create SAM-0001 PH >/dev/null; lab request create SAM-0001 TURBIDITY >/dev/null; lab request create SAM-0001 CHLORINE >/dev/null
D="$T/in"; mkdir -p "$D"

printf 'sample_id,test_code,value,unit\nSAM-0001,PH,7.1,pH\nSAM-0001,TURBIDITY,0.4,NTU\n' >"$D/good.csv"
lab import --dry-run "$D/good.csv"; expect_rc 0 "dry run succeeds" import --dry-run "$D/good.csv"
expect_eq "$(sql "SELECT count(*) FROM results;")" 0 "dry run writes nothing"
expect_rc 0 "valid file imports" import "$D/good.csv"
expect_eq "$(sql "SELECT count(*) FROM results;")" 2 "two results imported"
expect_eq "$(sql "SELECT status FROM samples WHERE code='SAM-0001';")" IN_TESTING "import moved sample to IN_TESTING"
expect_eq "$(sql "SELECT count(*) FROM audit_log WHERE action='IMPORT_EXECUTED';")" 1 "IMPORT_EXECUTED audited"
expect_eq "$(sql "SELECT count(*) FROM audit_log WHERE action='RESULT_CREATED' AND details='import';")" 2 "each row audited"

printf 'sample_id,test_code,value,unit\r\nSAM-0001,CHLORINE,0.5,mg/L\r\nSAM-9999,PH,7,pH\r\nSAM-0001,NOPE,1,x\r\nSAM-0001,PH,7.2,pH\r\nSAM-0002,PH,7,pH\r\nSAM-0001,CHLORINE,abc,mg/L\r\n' >"$D/mixed.csv"
lab import "$D/mixed.csv"
expect_eq "$RC" 3 "mixed file exits 3 (rows rejected)"
expect_out "imported: 1   rejected: 5" "report counts"
expect_out "does not exist" "reports missing sample"; expect_out "already has a result" "reports duplicate result"
expect_eq "$(sql "SELECT count(*) FROM results;")" 3 "only the valid row was imported"

printf 'sample_id,test_code,value,unit\nSAM-0001,PH,7,pH\nSAM-0001,PH,8,pH\n' >"$D/dup.csv"
lab import --dry-run "$D/dup.csv"; expect_out "duplicate SAM-0001/PH within the file" "duplicate rows inside file detected"
printf 'sample,test,value\nSAM-0001,PH,7\n' >"$D/badhdr.csv";  expect_rc 3 "wrong header rejected" import "$D/badhdr.csv"
printf 'sample_id,test_code,value,unit\n' >"$D/nodata.csv";     expect_rc 3 "header-only file rejected" import "$D/nodata.csv"
: >"$D/empty.csv";                                              expect_rc 3 "empty file rejected" import "$D/empty.csv"
printf 'sample_id,test_code,value,unit\nSAM-0001,"PH",7,pH\n' >"$D/quoted.csv"; expect_rc 3 "quoted fields rejected, not guessed" import "$D/quoted.csv"
printf 'sample_id,test_code,value,unit\nSAM-0001,PH,7\n' >"$D/short.csv"; expect_rc 3 "wrong column count rejected" import "$D/short.csv"
printf 'x' >"$D/notcsv.txt";                                    expect_rc 3 "non-.csv extension rejected" import "$D/notcsv.txt"
expect_rc 4 "missing file" import "$D/missing.csv"
expect_rc 6 "reviewer cannot import" --user reviewer1 import "$D/good.csv"
expect_eq "$(sql "SELECT count(*) FROM results;")" 3 "no rejected import changed the results"
finish
