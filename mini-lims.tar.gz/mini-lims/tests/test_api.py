"""API tests. Starts the real server on a random port against a temporary database."""
import json, os, shutil, subprocess, sys, tempfile, threading, unittest, urllib.request, urllib.error
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "src", "api"))
import server  # noqa: E402


class ApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.mkdtemp(prefix="lims-api-")
        os.environ.update(LAB_DB=f"{cls.tmp}/d/lims.db", LAB_LOG_FILE=f"{cls.tmp}/l/x.log",
                          LAB_BACKUP_DIR=f"{cls.tmp}/b", LAB_CONFIG="/dev/null")
        os.environ.pop("LAB_USER", None)
        subprocess.run([f"{ROOT}/bin/lab", "system", "init", "--seed"], check=True, capture_output=True)
        cls.httpd = server.make_server("127.0.0.1", 0)
        cls.base = f"http://127.0.0.1:{cls.httpd.server_address[1]}"
        threading.Thread(target=cls.httpd.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown(); shutil.rmtree(cls.tmp, ignore_errors=True)

    def call(self, method, path, body=None, user=None, raw=None):
        data = raw if raw is not None else (json.dumps(body).encode() if body is not None else None)
        req = urllib.request.Request(self.base + path, data=data, method=method)
        if user: req.add_header("X-Lab-User", user)
        try:
            with urllib.request.urlopen(req) as r: return r.status, json.loads(r.read())
        except urllib.error.HTTPError as e: return e.code, json.loads(e.read())

    def test_1_full_flow(self):
        s, b = self.call("POST", "/samples", {"client": "ACME", "type": "WATER", "collected": "2026-09-20"})
        self.assertEqual(s, 201); sid = b["code"]; self.assertEqual(b["status"], "RECEIVED")
        self.assertEqual(self.call("POST", f"/samples/{sid}/status", {"status": "REGISTERED"})[0], 200)
        self.assertEqual(self.call("POST", f"/samples/{sid}/requests", {"test": "PH"})[0], 201)
        s, b = self.call("POST", f"/samples/{sid}/results", {"test": "PH", "value": "9.2"})
        self.assertEqual((s, b["flag"]), (201, "HIGH"))
        s, b = self.call("GET", f"/samples/{sid}/results"); self.assertEqual((s, len(b)), (200, 1))
        s, b = self.call("GET", f"/audit/sample/{sid}"); self.assertEqual(s, 200)
        self.assertIn("RESULT_CREATED", [r["action"] for r in b])
        s, b = self.call("GET", f"/samples/{sid}"); self.assertEqual(b["status"], "IN_TESTING")
        s, b = self.call("GET", "/samples"); self.assertGreaterEqual(len(b), 1)

    def test_errors_map_to_http(self):
        self.assertEqual(self.call("GET", "/samples/SAM-9999")[0], 404)
        self.assertEqual(self.call("GET", "/samples/bad")[0], 400)
        s, b = self.call("POST", "/samples", {"client": "ACME", "type": "WATER"}); self.assertEqual(s, 400)
        s, b = self.call("POST", "/samples", {"client": "ACME", "type": "WATER", "collected": "2026-02-31"}); self.assertEqual(s, 422)
        s, b = self.call("POST", "/samples", {"client": "NOPE", "type": "WATER", "collected": "2026-09-20"}); self.assertEqual(s, 404)
        s, b = self.call("POST", "/samples", {"client": "ACME", "type": "WATER", "collected": "2026-09-20"}, user="reviewer1")
        self.assertEqual(s, 403); self.assertIn("Permission", b["error"])
        s, b = self.call("POST", "/samples", {"client": "ACME", "type": "WATER", "collected": "2026-09-20"}, user="ghost"); self.assertEqual(s, 403)

    def test_business_rules_apply_via_api(self):
        _, b = self.call("POST", "/samples", {"client": "ACME", "type": "WATER", "collected": "2026-09-20"}); sid = b["code"]
        s, _ = self.call("POST", f"/samples/{sid}/requests", {"test": "PH"}); self.assertEqual(s, 409)   # still RECEIVED
        s, _ = self.call("POST", f"/samples/{sid}/status", {"status": "APPROVED"}); self.assertEqual(s, 409)
        self.call("POST", f"/samples/{sid}/status", {"status": "REGISTERED"})
        s, _ = self.call("POST", f"/samples/{sid}/results", {"test": "PH", "value": "7"}); self.assertEqual(s, 409)  # not requested

    def test_bad_bodies(self):
        self.assertEqual(self.call("POST", "/samples", raw=b"{not json")[0], 400)
        self.assertEqual(self.call("POST", "/samples", raw=b"[1,2]")[0], 400)
        self.assertEqual(self.call("POST", "/samples", {"client": "ACME", "type": "WATER", "collected": "2026-09-20", "status": "APPROVED"})[0], 400)
        self.assertEqual(self.call("GET", "/nothing")[0], 404)
        self.assertEqual(self.call("GET", "/audit/bogus/x")[0], 400)

    def test_injection_value_is_data(self):
        s, b = self.call("POST", "/samples", {"client": "ACME", "type": "WATER", "collected": "2026-09-20",
                                              "description": "--user admin'; DROP TABLE samples;--"}, user="analyst1")
        self.assertEqual(s, 201); self.assertIn("DROP TABLE", b["description"])
        self.assertEqual(self.call("GET", "/samples")[0], 200)

    def test_tests_endpoint(self):
        s, b = self.call("GET", "/tests"); self.assertIn("PH", [t["code"] for t in b])
        s, b = self.call("POST", "/tests", {"code": "HARDNESS", "name": "Hardness", "datatype": "NUMERIC", "unit": "mg/L", "min": "0", "max": "300"})
        self.assertEqual((s, b["code"]), (201, "HARDNESS"))
        self.assertEqual(self.call("POST", "/tests", {"code": "HARDNESS", "name": "x", "datatype": "NUMERIC"})[0], 409)
        self.assertEqual(self.call("POST", "/tests", {"code": "H2", "name": "x", "datatype": "NUMERIC"}, user="analyst1")[0], 403)


if __name__ == "__main__":
    unittest.main(verbosity=1)
